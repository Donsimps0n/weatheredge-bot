"""
portfolio_manager.py
====================
Manages the portfolio of open positions as a whole — not trade by trade.

Three critical functions missing from v1/v2:

1. Correlation-Adjusted Kelly
   ──────────────────────────
   Betting NYC and Chicago temperature on the same day is NOT independent.
   Their temperatures correlate ~0.65. Treating them as independent bets
   dramatically overstates diversification and risks ruin.

   The portfolio Kelly formula for N correlated bets:
       Σ = correlation matrix of outcomes (N×N)
       f = Kelly fractions vector (N×1)
       Portfolio variance = f^T Σ f
       Scale f such that portfolio variance = sum of independent variances

2. Exit Strategy
   ──────────────
   The original bot has no mechanism to close positions early.
   If we buy YES at 0.40, and the model updates to P=0.20 two days later,
   we are sitting on a loser with no exit.

   Exit triggers:
   a) Model flips: new forecast gives edge < -MIN_EDGE on our current side
   b) Time decay: market hasn't moved toward our prediction with 24h left
   c) Stop-loss: position is down > MAX_LOSS_PCT of entry cost
   d) Price target: position reaches 0.85+ (take profit, don't get greedy)

3. Position Monitoring Loop
   ─────────────────────────
   Every FORECAST_REFRESH_SECONDS, re-evaluate all open positions.
   If any trigger fires → close the position.
"""

from __future__ import annotations

import logging
import sqlite3
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
from scipy.stats import norm

from config import cfg

log = logging.getLogger(__name__)

# ── Exit trigger thresholds ────────────────────────────────────────────────
MODEL_FLIP_THRESHOLD   = 0.05   # exit if model edge flips by > 5% against us
STOP_LOSS_PCT          = 0.40   # exit if position is down 40% from entry
TAKE_PROFIT_PRICE      = 0.88   # exit YES position if price reaches 88c
TAKE_PROFIT_PRICE_NO   = 0.12   # exit NO position if YES price drops to 12c
MIN_HOURS_BEFORE_EXIT  = 2.0    # don't exit a position within 2h of opening


# ─────────────────────────────────────────────────────────────────────────────
# City temperature correlation matrix
# Source: cross-correlation of daily max temperature anomalies 2010-2023
# ─────────────────────────────────────────────────────────────────────────────

CITY_CORRELATION: Dict[Tuple[str, str], float] = {
    # North America (high correlation — same air masses)
    ("New York",   "Chicago"):     0.65,
    ("New York",   "Miami"):       0.40,
    ("Chicago",    "Miami"):       0.35,
    # Europe
    ("London",     "Paris"):       0.82,
    ("London",     "Berlin"):      0.75,
    ("Paris",      "Berlin"):      0.80,
    # East Asia
    ("Tokyo",      "Seoul"):       0.71,
    ("Tokyo",      "Hong Kong"):   0.45,
    # Cross-continental (low — different weather systems)
    ("New York",   "London"):      0.20,
    ("New York",   "Tokyo"):       0.10,
    ("London",     "Tokyo"):       0.08,
    ("Dubai",      "Tel Aviv"):    0.60,
    ("Dubai",      "Tokyo"):       0.05,
}


def get_city_correlation(city_a: str, city_b: str) -> float:
    """Return temperature correlation between two cities (0 if unknown)."""
    if city_a == city_b:
        return 1.0
    return (CITY_CORRELATION.get((city_a, city_b))
            or CITY_CORRELATION.get((city_b, city_a))
            or 0.15)  # assume small positive default for unknown pairs


# ─────────────────────────────────────────────────────────────────────────────
# Open position container
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class OpenPosition:
    position_id:    str
    condition_id:   str
    city:           str
    target_date:    date
    bin_label:      str
    side:           str         # "YES" or "NO"
    entry_price:    float
    current_price:  float
    shares:         float
    cost_usd:       float
    opened_at:      datetime
    model_prob_at_entry: float
    current_model_prob:  float  = 0.0
    token_id:            str    = ""

    @property
    def unrealised_pnl(self) -> float:
        return self.shares * (self.current_price - self.entry_price)

    @property
    def pnl_pct(self) -> float:
        return (self.current_price - self.entry_price) / self.entry_price if self.entry_price else 0.0

    @property
    def hours_held(self) -> float:
        return (datetime.now(timezone.utc) - self.opened_at).total_seconds() / 3600

    @property
    def current_edge(self) -> float:
        """Current edge based on latest model probability."""
        if self.side == "YES":
            return self.current_model_prob - self.current_price
        else:
            return (1 - self.current_model_prob) - (1 - self.current_price)


# ─────────────────────────────────────────────────────────────────────────────
# Exit decision
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ExitDecision:
    position:    OpenPosition
    should_exit: bool
    reason:      str
    urgency:     str    # "IMMEDIATE", "SOON", "MONITOR"
    expected_exit_price: float

    def one_liner(self) -> str:
        flag = "🔴 EXIT" if self.should_exit else "✅ HOLD"
        return (
            f"{flag} {self.urgency} | {self.position.city} {self.position.target_date} "
            f"{self.position.bin_label} {self.position.side} | "
            f"entry={self.position.entry_price:.3f} now={self.position.current_price:.3f} "
            f"pnl={self.position.pnl_pct:+.1%} | {self.reason}"
        )


# ─────────────────────────────────────────────────────────────────────────────
# Portfolio Manager
# ─────────────────────────────────────────────────────────────────────────────

class PortfolioManager:
    """
    Portfolio-level position sizing and monitoring.

    Usage
    -----
        pm = PortfolioManager(bankroll=1000.0)

        # Before placing a new trade:
        adjusted_kelly = pm.correlation_adjusted_kelly(
            new_city="New York",
            new_date=date(2025, 7, 15),
            raw_kelly=0.08,
        )

        # In the monitoring loop:
        decisions = pm.evaluate_exits(open_positions, forecasts)
        for d in decisions:
            if d.should_exit:
                trader.close_position(d.position)
    """

    def __init__(self, bankroll: float) -> None:
        self.bankroll = bankroll

    # ── Correlation-adjusted Kelly ────────────────────────────────────────

    def correlation_adjusted_kelly(
        self,
        new_city:      str,
        new_date:      date,
        raw_kelly:     float,
        open_positions: List[OpenPosition],
    ) -> float:
        """
        Scale down raw Kelly fraction to account for correlation with
        existing open positions on the same or nearby date.

        Mathematics:
            Let f_i = Kelly fractions for positions i=1..N (existing)
            Let f_new = proposed new Kelly fraction
            Let ρ_ij = temperature correlation between city i and new city

            Independent portfolio variance = Σ f_i²  (if all ρ=0)
            Actual portfolio variance after adding new position:
                Var = Σ_i f_i² + f_new² + 2·f_new·Σ_i ρ_i·f_i

            We solve for f_new such that adding it does not increase
            portfolio variance beyond the independent-bets baseline:
                f_new² + 2·f_new·Σ_i ρ_i·f_i + (Var_current - Var_limit) = 0
        """
        # Only consider positions resolving within 2 days of new trade
        relevant = [
            p for p in open_positions
            if abs((p.target_date - new_date).days) <= 2
        ]

        if not relevant:
            return raw_kelly   # no correlated positions → no adjustment

        # Current portfolio variance (independent assumption)
        current_kellys    = np.array([p.cost_usd / self.bankroll for p in relevant])
        var_independent   = float(np.sum(current_kellys ** 2))

        # Correlation-weighted term
        corr_sum = sum(
            get_city_correlation(new_city, p.city) * (p.cost_usd / self.bankroll)
            for p in relevant
        )

        # Maximum allowed variance contribution from new bet
        # (we don't want portfolio variance to exceed the naive sum)
        var_limit     = var_independent + raw_kelly ** 2   # ideal: as if independent
        # Actual variance after adding f_new:
        # var_actual = var_independent + f_new² + 2·f_new·corr_sum
        # Set var_actual ≤ var_limit:
        #   f_new² + 2·f_new·corr_sum - raw_kelly² ≤ 0
        # Solve quadratic: f_new = (-2·corr_sum + sqrt(4·corr_sum² + 4·raw_kelly²)) / 2
        disc = corr_sum ** 2 + raw_kelly ** 2
        if disc < 0:
            return 0.0
        f_adj = -corr_sum + np.sqrt(disc)
        f_adj = float(np.clip(f_adj, 0.0, raw_kelly))

        if f_adj < raw_kelly:
            log.info(
                "Correlation adjustment: %s raw_kelly=%.4f → %.4f "
                "(corr_sum=%.3f, %d related positions)",
                new_city, raw_kelly, f_adj, corr_sum, len(relevant),
            )

        return f_adj

    # ── Exit strategy ─────────────────────────────────────────────────────

    def evaluate_exit(
        self,
        position: OpenPosition,
    ) -> ExitDecision:
        """
        Evaluate whether a single position should be closed.

        Returns ExitDecision with should_exit=True if any trigger fires.
        """
        # Don't exit within minimum hold period (avoid thrashing)
        if position.hours_held < MIN_HOURS_BEFORE_EXIT:
            return ExitDecision(
                position=position,
                should_exit=False,
                reason=f"too early ({position.hours_held:.1f}h < {MIN_HOURS_BEFORE_EXIT}h)",
                urgency="MONITOR",
                expected_exit_price=position.current_price,
            )

        # ── Trigger 1: Model flip ─────────────────────────────────────────
        # Our latest model now disagrees with our position
        if position.current_edge < -MODEL_FLIP_THRESHOLD:
            return ExitDecision(
                position=position,
                should_exit=True,
                reason=(
                    f"MODEL FLIP — entry_edge={position.model_prob_at_entry - position.entry_price:+.3f} "
                    f"current_edge={position.current_edge:+.3f}"
                ),
                urgency="IMMEDIATE",
                expected_exit_price=position.current_price,
            )

        # ── Trigger 2: Take profit ────────────────────────────────────────
        if position.side == "YES" and position.current_price >= TAKE_PROFIT_PRICE:
            return ExitDecision(
                position=position,
                should_exit=True,
                reason=f"TAKE PROFIT — price={position.current_price:.3f} ≥ {TAKE_PROFIT_PRICE}",
                urgency="SOON",
                expected_exit_price=position.current_price * 0.99,
            )

        if position.side == "NO" and position.current_price <= TAKE_PROFIT_PRICE_NO:
            return ExitDecision(
                position=position,
                should_exit=True,
                reason=f"TAKE PROFIT (NO) — YES price={position.current_price:.3f} ≤ {TAKE_PROFIT_PRICE_NO}",
                urgency="SOON",
                expected_exit_price=(1 - position.current_price) * 0.99,
            )

        # ── Trigger 3: Stop loss ──────────────────────────────────────────
        if position.pnl_pct < -STOP_LOSS_PCT:
            return ExitDecision(
                position=position,
                should_exit=True,
                reason=(
                    f"STOP LOSS — pnl={position.pnl_pct:.1%} < -{STOP_LOSS_PCT:.0%} | "
                    f"loss=${-position.unrealised_pnl:.2f}"
                ),
                urgency="IMMEDIATE",
                expected_exit_price=position.current_price,
            )

        # ── Trigger 4: Time decay — no movement with 24h left ─────────────
        days_to_resolve = (position.target_date - date.today()).days
        if days_to_resolve <= 1 and abs(position.current_edge) < 0.03:
            return ExitDecision(
                position=position,
                should_exit=True,
                reason=(
                    f"TIME DECAY — {days_to_resolve}d to resolve, "
                    f"edge={position.current_edge:+.3f} too small to hold"
                ),
                urgency="SOON",
                expected_exit_price=position.current_price,
            )

        return ExitDecision(
            position=position,
            should_exit=False,
            reason=(
                f"holding — edge={position.current_edge:+.3f} "
                f"pnl={position.pnl_pct:+.1%} "
                f"held={position.hours_held:.1f}h"
            ),
            urgency="MONITOR",
            expected_exit_price=position.current_price,
        )

    def evaluate_exits(
        self, positions: List[OpenPosition]
    ) -> List[ExitDecision]:
        """Evaluate all open positions. Returns sorted by urgency."""
        decisions = [self.evaluate_exit(p) for p in positions]
        urgency_order = {"IMMEDIATE": 0, "SOON": 1, "MONITOR": 2}
        decisions.sort(key=lambda d: urgency_order.get(d.urgency, 2))
        for d in decisions:
            log.info(d.one_liner())
        return decisions

    # ── Portfolio summary ─────────────────────────────────────────────────

    def portfolio_summary(self, positions: List[OpenPosition]) -> str:
        if not positions:
            return "No open positions."
        total_cost  = sum(p.cost_usd for p in positions)
        total_pnl   = sum(p.unrealised_pnl for p in positions)
        cities      = {p.city for p in positions}
        lines = [
            f"Portfolio: {len(positions)} positions | "
            f"invested=${total_cost:.2f} | "
            f"unrealised_pnl=${total_pnl:+.2f} | "
            f"cities={len(cities)}"
        ]
        for p in sorted(positions, key=lambda x: x.unrealised_pnl):
            lines.append(
                f"  {p.city:<12} {p.target_date} {p.bin_label} {p.side:<3} | "
                f"entry={p.entry_price:.3f} now={p.current_price:.3f} "
                f"pnl={p.pnl_pct:+.1%} edge={p.current_edge:+.3f}"
            )
        return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Self-test
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)

    pm = PortfolioManager(bankroll=1000.0)

    # Simulate two existing positions: NYC and Chicago (corr=0.65)
    existing = [
        OpenPosition(
            position_id="p1",
            condition_id="cid1",
            city="New York",
            target_date=date(2025, 7, 15),
            bin_label=">85°F",
            side="YES",
            entry_price=0.42,
            current_price=0.50,
            shares=23.8,
            cost_usd=10.0,
            opened_at=datetime.now(timezone.utc) - timedelta(hours=3),
            model_prob_at_entry=0.62,
            current_model_prob=0.62,
        )
    ]

    raw_kelly   = 0.08
    adj_kelly   = pm.correlation_adjusted_kelly("Chicago", date(2025, 7, 15), raw_kelly, existing)
    print(f"\nKelly for Chicago (NYC open, ρ=0.65):")
    print(f"  Raw:      {raw_kelly:.4f} ({raw_kelly*100:.1f}%)")
    print(f"  Adjusted: {adj_kelly:.4f} ({adj_kelly*100:.1f}%)")
    print(f"  Reduced:  {(raw_kelly-adj_kelly)*100:.1f}%")

    print()
    decisions = pm.evaluate_exits(existing)
    for d in decisions:
        print(d.one_liner())

    # Simulate a model flip
    existing[0].current_model_prob = 0.25   # model now says 25% — we hold YES
    existing[0].current_price = 0.48
    print("\nAfter model flip to 25%:")
    decisions = pm.evaluate_exits(existing)
    for d in decisions:
        print(d.one_liner())

    print()
    print(pm.portfolio_summary(existing))
