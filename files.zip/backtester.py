"""
backtester.py
=============
Replays the bot's strategy over historical Polymarket weather markets to
measure edge accuracy, calibration, and P&L.

What it does
------------
1. Pulls historical market data from the Gamma API (closed/resolved markets).
2. For each resolved temperature market:
   a. Fetches what the Open-Meteo GFS ensemble was predicting on the eve
      of the market close (via archive API).
   b. Computes model_prob using probability_calculator.
   c. Computes edge vs the market's settlement price (last known price).
   d. Simulates paper trades (would we have traded? at what size?).
   e. Checks the actual resolved outcome to compute realised P&L.
3. Aggregates into a full P&L report with calibration statistics.

Calibration
-----------
A well-calibrated model means: when we say 70% probability, the outcome
occurs ~70% of the time.  We plot the reliability diagram by grouping
predictions into 10 buckets and comparing mean prediction vs observed rate.

Output
------
Prints a summary report to stdout and saves a JSON file to backtest_results/.

Usage
-----
    python backtester.py --days 60
    python backtester.py --days 30 --city "New York"
    python backtester.py --days 90 --min-edge 0.08
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import asdict, dataclass
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import requests

from config import cfg, get_city_coords
from market_scanner import BinRange, MarketParser, WeatherMarket
from forecast_fetcher import ForecastFetcher
from probability_calculator import ProbabilityCalculator
from edge_calculator import EdgeCalculator

log = logging.getLogger(__name__)

GAMMA_BASE = cfg.polymarket.gamma_host


# ---------------------------------------------------------------------------
# Data containers
# ---------------------------------------------------------------------------

@dataclass
class BacktestTrade:
    """One simulated trade from the backtest replay."""
    condition_id:   str
    city:           str
    target_date:    str         # ISO date
    bin_label:      str
    side:           str
    model_prob:     float
    market_price:   float       # price at time of simulated entry
    edge:           float
    ev_net:         float
    simulated_size: float       # dollar size (before fees)
    fill_price:     float       # pessimistic fill
    outcome:        Optional[bool] = None   # True=YES resolved, False=NO
    pnl_usd:        Optional[float] = None  # realised P&L
    notes:          str = ""


@dataclass
class BacktestReport:
    """Aggregated results across all backtested trades."""
    days:            int
    start_date:      str
    end_date:        str
    n_markets_found: int
    n_parseable:     int
    n_forecast_ok:   int
    n_tradeable:     int        # passed edge filter
    n_simulated:     int        # actually simulated (pos. Kelly)
    total_wagered:   float
    total_pnl:       float
    roi:             float      # total_pnl / total_wagered
    win_rate:        float      # fraction of winning trades
    avg_edge:        float
    avg_ev_net:      float
    sharpe:          float      # daily P&L Sharpe
    max_drawdown:    float      # largest peak-to-trough loss
    calibration:     Dict       # bucket → {pred_mean, obs_rate, count}
    trades:          List[BacktestTrade]


# ---------------------------------------------------------------------------
# Backtest engine
# ---------------------------------------------------------------------------

class Backtester:

    def __init__(
        self,
        days:       int  = 60,
        city_filter: Optional[str] = None,
        min_edge:   float = None,
        bankroll:   float = 1000.0,
    ) -> None:
        self.days        = days
        self.city_filter = city_filter
        self.min_edge    = min_edge if min_edge is not None else cfg.risk.min_edge
        self.bankroll    = bankroll

        self.forecaster = ForecastFetcher()
        self.calc       = ProbabilityCalculator(use_kde=True)
        self.edge_calc  = EdgeCalculator(bankroll=bankroll)
        self.parser     = MarketParser()
        self.session    = requests.Session()
        self.session.headers["User-Agent"] = "polymarket-weather-bot/backtest"

    # ── Main run ─────────────────────────────────────────────────────────

    def run(self) -> BacktestReport:
        end_date   = date.today() - timedelta(days=1)   # yesterday
        start_date = end_date - timedelta(days=self.days)

        log.info(
            "Backtest: %s → %s | min_edge=%.2f | city=%s",
            start_date, end_date, self.min_edge, self.city_filter or "ALL"
        )

        raw_markets = self._fetch_resolved_markets(start_date, end_date)
        log.info("Fetched %d resolved market candidates", len(raw_markets))

        trades: List[BacktestTrade] = []
        n_parseable = n_forecast_ok = n_tradeable = 0

        for raw in raw_markets:
            parsed = self._parse_raw(raw)
            if not parsed:
                continue
            market, resolved_yes = parsed
            n_parseable += 1

            if self.city_filter and market.city != self.city_filter:
                continue

            # Get what the model was predicting the day before
            forecast = self.forecaster.get_past_ensemble(
                market.city, market.target_date
            )
            if not forecast or len(forecast.daily_max_samples) < cfg.weather.min_ensemble_members:
                log.debug("No usable forecast for %s %s", market.city, market.target_date)
                continue
            n_forecast_ok += 1

            model_prob = self.calc.market_probability(market, forecast)
            edge_result = self.edge_calc.best_side(market, model_prob)

            if edge_result.edge < self.min_edge:
                continue
            n_tradeable += 1

            if not edge_result.is_tradeable:
                continue

            # Simulate the trade
            trade = self._simulate_trade(market, edge_result, resolved_yes)
            trades.append(trade)

            # Update running bankroll for realistic sizing
            if trade.pnl_usd is not None:
                self.bankroll = max(1.0, self.bankroll + trade.pnl_usd)
                self.edge_calc.update_bankroll(self.bankroll)

            # Rate-limit to be polite to the API
            time.sleep(0.1)

        report = self._build_report(
            start_date=start_date, end_date=end_date,
            n_markets=len(raw_markets),
            n_parseable=n_parseable,
            n_forecast_ok=n_forecast_ok,
            n_tradeable=n_tradeable,
            trades=trades,
        )

        self._save_report(report)
        self._print_report(report)
        return report

    # ── Market fetching ───────────────────────────────────────────────────

    def _fetch_resolved_markets(
        self, start: date, end: date
    ) -> List[dict]:
        """Pull resolved weather markets from Gamma for the date range."""
        all_markets: List[dict] = []

        for tag in ("Weather", "Forecast"):
            try:
                resp = self.session.get(
                    f"{GAMMA_BASE}/markets",
                    params={
                        "tag":    tag,
                        "active": "false",
                        "closed": "true",
                        "limit":  500,
                        "after":  start.isoformat(),
                        "before": end.isoformat(),
                    },
                    timeout=20,
                )
                resp.raise_for_status()
                data = resp.json()
                markets = data if isinstance(data, list) else data.get("markets", [])
                all_markets.extend(markets)
            except Exception as exc:
                log.warning("Gamma resolved fetch failed for %r: %s", tag, exc)

        # Deduplicate
        seen: set = set()
        unique = []
        for m in all_markets:
            cid = m.get("conditionId", "")
            if cid and cid not in seen:
                seen.add(cid)
                unique.append(m)

        return unique

    # ── Market parsing ────────────────────────────────────────────────────

    def _parse_raw(
        self, raw: dict
    ) -> Optional[Tuple[WeatherMarket, Optional[bool]]]:
        """
        Parse a raw resolved market dict.

        Returns (WeatherMarket, resolved_yes) where resolved_yes is True if
        the Yes outcome paid out, False if No paid out, None if unknown.
        """
        question = raw.get("question") or raw.get("title") or ""
        if not self.parser.is_temperature_market(question):
            return None

        city = self.parser.extract_city(question, cfg.cities)
        if not city:
            return None

        target_date = self.parser.extract_date(question)
        if not target_date:
            return None

        bin_range = self.parser.extract_bin(question)
        if not bin_range:
            return None

        # Try to extract last traded price
        last_price = float(raw.get("lastTradePrice") or raw.get("price") or 0.5)
        volume     = float(raw.get("volume") or raw.get("volumeUsd") or 0.0)
        tick_size  = float(raw.get("minimumTickSize") or 0.01)
        neg_risk   = bool(raw.get("negRisk", False))

        clob_ids   = raw.get("clobTokenIds") or []
        if isinstance(clob_ids, str):
            import json as _json
            try:   clob_ids = _json.loads(clob_ids)
            except Exception: clob_ids = []

        market = WeatherMarket(
            condition_id=raw.get("conditionId", ""),
            market_slug=raw.get("slug", ""),
            question=question,
            clob_token_ids=[str(t) for t in clob_ids],
            tick_size=tick_size,
            neg_risk=neg_risk,
            city=city,
            target_date=target_date,
            bin_range=bin_range,
            outcome_index=0,
            mid_price=last_price,
            best_bid=last_price - tick_size,
            best_ask=last_price + tick_size,
            volume_usd=volume,
            liquidity_usd=volume * 0.1,
        )

        # Resolved outcome
        resolved_raw = raw.get("resolution") or raw.get("outcome") or ""
        resolved_yes: Optional[bool] = None
        if str(resolved_raw).upper() in ("YES", "1", "TRUE"):
            resolved_yes = True
        elif str(resolved_raw).upper() in ("NO", "0", "FALSE"):
            resolved_yes = False

        return market, resolved_yes

    # ── Trade simulation ──────────────────────────────────────────────────

    def _simulate_trade(
        self,
        market:      WeatherMarket,
        edge_result,
        resolved_yes: Optional[bool],
    ) -> BacktestTrade:
        side      = edge_result.side
        price     = edge_result.market_price
        fill_price = min(price + market.tick_size * 0.5, 0.999)
        size_usd  = edge_result.position_usd
        fee       = size_usd * 0.02     # 2% taker fee

        pnl: Optional[float] = None
        if resolved_yes is not None:
            won = (side == "YES" and resolved_yes) or (side == "NO" and not resolved_yes)
            if won:
                # Won: receive $1 per share bought; shares = size_usd / fill_price
                shares = size_usd / fill_price
                pnl = shares * (1.0 - fill_price) - fee   # net profit
            else:
                pnl = -size_usd  # total loss (minus fee already subtracted)

        return BacktestTrade(
            condition_id=market.condition_id,
            city=market.city,
            target_date=str(market.target_date),
            bin_label=market.bin_range.label,
            side=side,
            model_prob=edge_result.model_prob,
            market_price=price,
            edge=edge_result.edge,
            ev_net=edge_result.ev_net,
            simulated_size=size_usd,
            fill_price=fill_price,
            outcome=resolved_yes,
            pnl_usd=pnl,
            notes=edge_result.note[:120],
        )

    # ── Report building ───────────────────────────────────────────────────

    def _build_report(
        self,
        start_date: date,
        end_date:   date,
        n_markets:  int,
        n_parseable: int,
        n_forecast_ok: int,
        n_tradeable: int,
        trades:     List[BacktestTrade],
    ) -> BacktestReport:
        resolved  = [t for t in trades if t.pnl_usd is not None]
        wagered   = sum(t.simulated_size for t in resolved)
        total_pnl = sum(t.pnl_usd for t in resolved)   # type: ignore
        winners   = [t for t in resolved if (t.pnl_usd or 0) > 0]

        roi        = total_pnl / wagered if wagered else 0.0
        win_rate   = len(winners) / len(resolved) if resolved else 0.0
        avg_edge   = float(np.mean([t.edge for t in trades])) if trades else 0.0
        avg_ev_net = float(np.mean([t.ev_net for t in trades])) if trades else 0.0

        # Daily P&L for Sharpe
        daily_pnl: Dict[str, float] = {}
        for t in resolved:
            daily_pnl.setdefault(t.target_date, 0.0)
            daily_pnl[t.target_date] += t.pnl_usd  # type: ignore
        daily_series = list(daily_pnl.values())
        sharpe = (
            float(np.mean(daily_series) / np.std(daily_series))
            if len(daily_series) > 1
            else 0.0
        )

        # Max drawdown
        cumulative = np.cumsum(daily_series)
        running_max = np.maximum.accumulate(cumulative)
        drawdowns = running_max - cumulative
        max_dd = float(np.max(drawdowns)) if len(drawdowns) else 0.0

        # Calibration: group predictions into decile buckets
        calibration = self._compute_calibration(resolved)

        return BacktestReport(
            days=self.days,
            start_date=str(start_date),
            end_date=str(end_date),
            n_markets_found=n_markets,
            n_parseable=n_parseable,
            n_forecast_ok=n_forecast_ok,
            n_tradeable=n_tradeable,
            n_simulated=len(trades),
            total_wagered=wagered,
            total_pnl=total_pnl,
            roi=roi,
            win_rate=win_rate,
            avg_edge=avg_edge,
            avg_ev_net=avg_ev_net,
            sharpe=sharpe,
            max_drawdown=max_dd,
            calibration=calibration,
            trades=trades,
        )

    @staticmethod
    def _compute_calibration(trades: List[BacktestTrade]) -> Dict:
        """
        Reliability diagram data.
        Group trades into 10 bins by model_prob, compute observed win rate per bin.
        """
        buckets: Dict[str, Dict] = {}
        edges = np.linspace(0, 1, 11)
        for lo, hi in zip(edges[:-1], edges[1:]):
            label = f"{lo:.1f}-{hi:.1f}"
            relevant = [
                t for t in trades
                if lo <= t.model_prob < hi and t.outcome is not None
            ]
            if relevant:
                obs_rate = sum(1 for t in relevant
                               if (t.side == "YES" and t.outcome) or
                                  (t.side == "NO" and not t.outcome)) / len(relevant)
                buckets[label] = {
                    "pred_mean":  float(np.mean([t.model_prob for t in relevant])),
                    "obs_rate":   obs_rate,
                    "count":      len(relevant),
                }
        return buckets

    # ── Output ────────────────────────────────────────────────────────────

    def _save_report(self, report: BacktestReport) -> None:
        out_dir = Path("backtest_results")
        out_dir.mkdir(exist_ok=True)
        fname = out_dir / f"{report.end_date}_backtest_{report.days}d.json"
        data  = asdict(report)
        data["trades"] = [asdict(t) for t in report.trades]
        fname.write_text(json.dumps(data, indent=2))
        log.info("Backtest saved to %s", fname)

    def _print_report(self, r: BacktestReport) -> None:
        bar  = "=" * 60
        win  = r.win_rate * 100
        roi  = r.roi * 100
        print(f"\n{bar}")
        print(f"  BACKTEST REPORT  ({r.start_date} → {r.end_date})")
        print(bar)
        print(f"  Markets found:     {r.n_markets_found}")
        print(f"  Parseable:         {r.n_parseable}")
        print(f"  Forecast OK:       {r.n_forecast_ok}")
        print(f"  Had edge:          {r.n_tradeable}")
        print(f"  Simulated trades:  {r.n_simulated}")
        print(f"  Total wagered:     ${r.total_wagered:>9,.2f}")
        print(f"  Total P&L:         ${r.total_pnl:>+9,.2f}")
        print(f"  ROI:               {roi:>+.1f}%")
        print(f"  Win rate:          {win:.1f}%")
        print(f"  Avg edge:          {r.avg_edge:.2%}")
        print(f"  Avg net EV:        {r.avg_ev_net:.4f}")
        print(f"  Sharpe (daily):    {r.sharpe:.2f}")
        print(f"  Max drawdown:      ${r.max_drawdown:,.2f}")
        print(f"\n  Calibration:")
        for bucket, stats in r.calibration.items():
            bar_len = int(stats["obs_rate"] * 20)
            print(
                f"    [{bucket}]  pred={stats['pred_mean']:.2f}  "
                f"obs={stats['obs_rate']:.2f}  n={stats['count']}  "
                f"{'█'*bar_len}"
            )
        print(bar + "\n")


# ---------------------------------------------------------------------------
# CLI entrypoint
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse
    logging.basicConfig(level=logging.INFO)

    parser = argparse.ArgumentParser(description="Polymarket Weather Backtester")
    parser.add_argument("--days",     type=int,   default=60,   help="Lookback window (days)")
    parser.add_argument("--city",     type=str,   default=None, help="Filter to one city")
    parser.add_argument("--min-edge", type=float, default=None, help="Min edge threshold")
    parser.add_argument("--bankroll", type=float, default=1000.0)
    args = parser.parse_args()

    bt = Backtester(
        days=args.days,
        city_filter=args.city,
        min_edge=args.min_edge,
        bankroll=args.bankroll,
    )
    bt.run()
