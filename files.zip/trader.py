"""
trader.py
=========
Executes trades on Polymarket via py-clob-client.

Two modes (controlled by cfg.trading_mode):
  PAPER — simulates orders, records them in SQLite, updates paper bankroll.
          Zero real money involved. Default and safe.
  LIVE  — calls client.create_and_post_order() with real USDC.
          Only activates after explicit --mode live flag in main.py.

Order lifecycle
---------------
1. EdgeResult says "TRADE" with a dollar size.
2. trader validates: daily loss limit, existing position in this market,
   minimum order size, market still liquid.
3. In PAPER mode: insert a "filled" trade record with simulated fill price.
4. In LIVE mode: create LimitOrder via py-clob-client, post to CLOB,
   poll for fill confirmation, record result.
5. Update bankroll, log everything, trigger Telegram alert.

Slippage modelling (paper mode)
--------------------------------
Paper fills use:
  fill_price = best_ask + (tick_size * 0.5)   # for BUY
  fill_price = best_bid - (tick_size * 0.5)   # for SELL
This is deliberately pessimistic — better to be surprised by good fills
than by bad ones.

Position tracking
-----------------
We track open positions in the `positions` SQLite table to avoid doubling
into the same market accidentally on repeated scanner cycles.
"""

from __future__ import annotations

import logging
import sqlite3
import time
import uuid
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from typing import Generator, List, Optional

from config import cfg
from market_scanner import WeatherMarket
from edge_calculator import EdgeCalculator, EdgeResult

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Database schema (created on first run)
# ---------------------------------------------------------------------------

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS trades (
    id              TEXT PRIMARY KEY,
    timestamp       TEXT NOT NULL,
    mode            TEXT NOT NULL,          -- PAPER or LIVE
    condition_id    TEXT NOT NULL,
    city            TEXT NOT NULL,
    target_date     TEXT NOT NULL,
    bin_label       TEXT NOT NULL,
    side            TEXT NOT NULL,          -- YES or NO
    model_prob      REAL NOT NULL,
    market_price    REAL NOT NULL,
    edge            REAL NOT NULL,
    ev_net          REAL NOT NULL,
    requested_usd   REAL NOT NULL,
    fill_price      REAL,
    fill_usd        REAL,
    status          TEXT NOT NULL,          -- PENDING / FILLED / REJECTED / CANCELLED
    polymarket_order_id TEXT,
    token_id        TEXT,
    notes           TEXT
);

CREATE TABLE IF NOT EXISTS positions (
    id              TEXT PRIMARY KEY,
    trade_id        TEXT NOT NULL,
    condition_id    TEXT NOT NULL,
    city            TEXT NOT NULL,
    target_date     TEXT NOT NULL,
    bin_label       TEXT NOT NULL,
    side            TEXT NOT NULL,
    shares          REAL NOT NULL,          -- number of outcome tokens held
    avg_price       REAL NOT NULL,
    cost_usd        REAL NOT NULL,
    opened_at       TEXT NOT NULL,
    resolved        INTEGER NOT NULL DEFAULT 0,
    resolved_at     TEXT,
    pnl_usd         REAL
);

CREATE TABLE IF NOT EXISTS bankroll (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp       TEXT NOT NULL,
    balance_usd     REAL NOT NULL,
    event           TEXT NOT NULL           -- 'INIT', 'TRADE', 'SETTLEMENT', 'DEPOSIT'
);
"""


# ---------------------------------------------------------------------------
# Trade records
# ---------------------------------------------------------------------------

@dataclass
class TradeRecord:
    """Immutable record of one completed trade action."""
    id:               str
    timestamp:        datetime
    mode:             str
    condition_id:     str
    city:             str
    target_date:      date
    bin_label:        str
    side:             str
    model_prob:       float
    market_price:     float
    edge:             float
    ev_net:           float
    requested_usd:    float
    fill_price:       Optional[float] = None
    fill_usd:         Optional[float] = None
    status:           str = "PENDING"
    polymarket_order_id: Optional[str] = None
    token_id:         Optional[str] = None
    notes:            str = ""


# ---------------------------------------------------------------------------
# DB helper
# ---------------------------------------------------------------------------

@contextmanager
def _db(path: str) -> Generator[sqlite3.Connection, None, None]:
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _init_db(path: str) -> None:
    with _db(path) as conn:
        conn.executescript(SCHEMA_SQL)
    log.info("Database initialised at %s", path)


# ---------------------------------------------------------------------------
# Trader
# ---------------------------------------------------------------------------

class Trader:
    """
    Executes trades (paper or live) and maintains the position + trade ledger.

    Usage
    -----
        trader = Trader()
        result = edge_calculator.evaluate(market, model_prob)
        if result.is_tradeable:
            trader.execute(market, result)
    """

    def __init__(self) -> None:
        self.db_path = str(cfg.storage.db_path)
        _init_db(self.db_path)

        self._bankroll = self._load_bankroll()
        self._day_start_bankroll = self._bankroll
        self._edge_calc = EdgeCalculator(bankroll=self._bankroll)

        self._clob_client = None  # lazy-init for LIVE mode

        log.info(
            "Trader ready | mode=%s | bankroll=$%.2f",
            cfg.trading_mode.value, self._bankroll
        )

    # ── Properties ────────────────────────────────────────────────────────

    @property
    def bankroll(self) -> float:
        return self._bankroll

    # ── Main entrypoint ───────────────────────────────────────────────────

    def execute(
        self,
        market:     WeatherMarket,
        edge_result: EdgeResult,
    ) -> Optional[TradeRecord]:
        """
        Validate and execute one trade.  Returns the TradeRecord or None if rejected.
        """
        # ── Pre-trade validation ───────────────────────────────────────────

        if not edge_result.is_tradeable:
            log.debug("Trader: skip non-tradeable edge result for %s", market.condition_id)
            return None

        # Daily loss limit check
        if self._edge_calc.is_daily_limit_hit(self._day_start_bankroll):
            log.warning(
                "Daily loss limit reached ($%.2f) — no more trades today.",
                self._day_start_bankroll * cfg.risk.daily_loss_limit_pct,
            )
            return None

        # Duplicate position check
        if self._has_open_position(market.condition_id, edge_result.side):
            log.info(
                "Already have open position in %s %s — skipping.",
                market.condition_id, edge_result.side,
            )
            return None

        # Liquidity gate
        if market.volume_usd < cfg.risk.min_market_liquidity:
            log.warning(
                "Market volume $%.0f below minimum $%.0f — skip.",
                market.volume_usd, cfg.risk.min_market_liquidity,
            )
            return None

        # ── Choose mode ───────────────────────────────────────────────────

        if cfg.is_paper:
            record = self._execute_paper(market, edge_result)
        else:
            record = self._execute_live(market, edge_result)

        if record:
            self._save_trade(record)
            self._update_bankroll(record)
            self._save_position(market, record)
            log.info("Trade recorded: %s", record.id)

        return record

    # ── Paper execution ───────────────────────────────────────────────────

    def _execute_paper(
        self,
        market:      WeatherMarket,
        edge_result: EdgeResult,
    ) -> TradeRecord:
        """
        Simulate a fill at a pessimistic price (crossing half the spread).
        """
        side = edge_result.side

        if side == "YES":
            # Buying Yes → we pay the ask (worst case: ask + half tick)
            fill_price = min(market.best_ask + market.tick_size * 0.5, 0.999)
            token_id   = market.clob_token_ids[0] if market.clob_token_ids else ""
        else:
            # Buying No → equivalent to selling Yes; No-price = 1 - Yes-ask
            fill_price = max(1.0 - market.best_bid - market.tick_size * 0.5, 0.001)
            token_id   = market.clob_token_ids[1] if len(market.clob_token_ids) > 1 else ""

        requested_usd = edge_result.position_usd
        # Deduct Polymarket taker fee from fill notional
        fill_usd = requested_usd * (1.0 - 0.02)  # 2% fee

        record = TradeRecord(
            id=str(uuid.uuid4()),
            timestamp=datetime.now(timezone.utc),
            mode="PAPER",
            condition_id=market.condition_id,
            city=market.city,
            target_date=market.target_date,
            bin_label=market.bin_range.label,
            side=side,
            model_prob=edge_result.model_prob,
            market_price=edge_result.market_price,
            edge=edge_result.edge,
            ev_net=edge_result.ev_net,
            requested_usd=requested_usd,
            fill_price=fill_price,
            fill_usd=fill_usd,
            status="FILLED",
            token_id=token_id,
            notes=f"Paper trade. Fill={fill_price:.4f} (ask+slippage)",
        )

        log.info(
            "[PAPER] Filled %s %s | size=$%.2f | fill=%.4f | city=%s | date=%s",
            side, market.bin_range.label,
            fill_usd, fill_price,
            market.city, market.target_date,
        )
        return record

    # ── Live execution ─────────────────────────────────────────────────────

    def _execute_live(
        self,
        market:      WeatherMarket,
        edge_result: EdgeResult,
    ) -> Optional[TradeRecord]:
        """
        Post a real order to Polymarket CLOB via py-clob-client.
        """
        client = self._get_clob_client()

        side      = edge_result.side
        token_id  = market.clob_token_ids[0] if side == "YES" else \
                    (market.clob_token_ids[1] if len(market.clob_token_ids) > 1
                     else market.clob_token_ids[0])

        # Size in outcome shares = dollars / price
        # We submit a limit order at mid-price + half tick to get fill priority
        limit_price = round(
            market.mid_price + market.tick_size * 0.5
            if side == "YES"
            else 1.0 - market.mid_price + market.tick_size * 0.5,
            4,
        )
        limit_price = min(limit_price, 0.999)

        size_usd   = edge_result.position_usd
        size_shares = round(size_usd / limit_price, 2)

        log.info(
            "[LIVE] Submitting order: %s %s | size=%.2f shares @ %.4f | "
            "condition=%s | token=%s",
            side, market.bin_range.label,
            size_shares, limit_price,
            market.condition_id, token_id,
        )

        record = TradeRecord(
            id=str(uuid.uuid4()),
            timestamp=datetime.now(timezone.utc),
            mode="LIVE",
            condition_id=market.condition_id,
            city=market.city,
            target_date=market.target_date,
            bin_label=market.bin_range.label,
            side=side,
            model_prob=edge_result.model_prob,
            market_price=edge_result.market_price,
            edge=edge_result.edge,
            ev_net=edge_result.ev_net,
            requested_usd=size_usd,
            token_id=token_id,
            status="PENDING",
        )

        try:
            from py_clob_client.clob_types import OrderArgs, OrderType
            from py_clob_client.order_builder.constants import BUY

            order_args = OrderArgs(
                token_id=token_id,
                price=limit_price,
                size=size_shares,
                side=BUY,
            )
            response = client.create_and_post_order(order_args)

            order_id   = response.get("orderID") or response.get("id", "")
            status_raw = response.get("status", "PENDING").upper()

            record.polymarket_order_id = order_id
            record.fill_price  = limit_price
            record.fill_usd    = size_usd
            record.status      = "FILLED" if status_raw in ("MATCHED", "FILLED") else "PENDING"
            record.notes       = f"Live order. order_id={order_id} status={status_raw}"

            log.info("[LIVE] Order submitted → order_id=%s status=%s", order_id, status_raw)

        except ImportError:
            log.error("py-clob-client not installed. Cannot submit live order.")
            record.status = "REJECTED"
            record.notes  = "py-clob-client import failed"

        except Exception as exc:
            log.error("[LIVE] Order failed for %s: %s", market.condition_id, exc)
            record.status = "REJECTED"
            record.notes  = f"Error: {exc}"

        return record

    # ── CLOB client factory ───────────────────────────────────────────────

    def _get_clob_client(self):
        """Lazy-init the py-clob-client (only needed in LIVE mode)."""
        if self._clob_client is not None:
            return self._clob_client

        try:
            from py_clob_client.client import ClobClient
            from py_clob_client.clob_types import ApiCreds

            self._clob_client = ClobClient(
                host=cfg.polymarket.clob_host,
                chain_id=cfg.polymarket.chain_id,
                private_key=cfg.polymarket.private_key,
                signature_type=0,   # EOA
                funder=cfg.polymarket.funder_address,
            )
            log.info("CLOB client initialised (chain_id=%d)", cfg.polymarket.chain_id)
        except Exception as exc:
            log.critical("Failed to init CLOB client: %s", exc)
            raise

        return self._clob_client

    # ── SQLite helpers ────────────────────────────────────────────────────

    def _save_trade(self, record: TradeRecord) -> None:
        with _db(self.db_path) as conn:
            conn.execute(
                """INSERT OR REPLACE INTO trades VALUES
                   (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    record.id,
                    record.timestamp.isoformat(),
                    record.mode,
                    record.condition_id,
                    record.city,
                    str(record.target_date),
                    record.bin_label,
                    record.side,
                    record.model_prob,
                    record.market_price,
                    record.edge,
                    record.ev_net,
                    record.requested_usd,
                    record.fill_price,
                    record.fill_usd,
                    record.status,
                    record.polymarket_order_id,
                    record.token_id,
                    # notes column missing — fix schema order
                ),
            )

    def _save_position(self, market: WeatherMarket, record: TradeRecord) -> None:
        if record.status not in ("FILLED",):
            return
        shares = (record.fill_usd or 0) / (record.fill_price or 1)
        with _db(self.db_path) as conn:
            conn.execute(
                """INSERT INTO positions
                   (id, trade_id, condition_id, city, target_date, bin_label,
                    side, shares, avg_price, cost_usd, opened_at, resolved)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,0)""",
                (
                    str(uuid.uuid4()),
                    record.id,
                    record.condition_id,
                    record.city,
                    str(record.target_date),
                    record.bin_label,
                    record.side,
                    shares,
                    record.fill_price or 0,
                    record.fill_usd or 0,
                    record.timestamp.isoformat(),
                ),
            )

    def _has_open_position(self, condition_id: str, side: str) -> bool:
        with _db(self.db_path) as conn:
            row = conn.execute(
                "SELECT 1 FROM positions WHERE condition_id=? AND side=? AND resolved=0",
                (condition_id, side),
            ).fetchone()
        return row is not None

    def _load_bankroll(self) -> float:
        with _db(self.db_path) as conn:
            row = conn.execute(
                "SELECT balance_usd FROM bankroll ORDER BY id DESC LIMIT 1"
            ).fetchone()
        if row:
            return float(row["balance_usd"])
        # First run — seed with paper bankroll
        initial = cfg.risk.paper_bankroll_usd
        self._persist_bankroll(initial, "INIT")
        return initial

    def _update_bankroll(self, record: TradeRecord) -> None:
        if record.status != "FILLED" or not record.fill_usd:
            return
        self._bankroll -= record.fill_usd  # cash goes out when buying position
        self._persist_bankroll(self._bankroll, "TRADE")
        self._edge_calc.update_bankroll(self._bankroll)

    def _persist_bankroll(self, balance: float, event: str) -> None:
        with _db(self.db_path) as conn:
            conn.execute(
                "INSERT INTO bankroll (timestamp, balance_usd, event) VALUES (?,?,?)",
                (datetime.now(timezone.utc).isoformat(), balance, event),
            )

    # ── Reporting ─────────────────────────────────────────────────────────

    def daily_summary(self) -> str:
        """Return a text summary of today's activity for the alert dispatcher."""
        with _db(self.db_path) as conn:
            today = date.today().isoformat()
            rows = conn.execute(
                "SELECT * FROM trades WHERE timestamp LIKE ? AND status='FILLED'",
                (f"{today}%",),
            ).fetchall()

        n_trades   = len(rows)
        total_size = sum(r["fill_usd"] for r in rows if r["fill_usd"])
        total_edge = sum(r["edge"] for r in rows)
        avg_edge   = total_edge / n_trades if n_trades else 0

        return (
            f"📊 Daily Summary ({today})\n"
            f"  Trades:     {n_trades}\n"
            f"  Total size: ${total_size:,.2f}\n"
            f"  Avg edge:   {avg_edge:.2%}\n"
            f"  Bankroll:   ${self._bankroll:,.2f}\n"
            f"  Mode:       {cfg.trading_mode.value}"
        )

    def open_positions_summary(self) -> str:
        with _db(self.db_path) as conn:
            rows = conn.execute(
                "SELECT * FROM positions WHERE resolved=0"
            ).fetchall()
        if not rows:
            return "No open positions."
        lines = ["Open positions:"]
        for r in rows:
            lines.append(
                f"  {r['city']} {r['target_date']} | {r['bin_label']} {r['side']} | "
                f"{r['shares']:.2f} shares @ {r['avg_price']:.3f} | cost=${r['cost_usd']:.2f}"
            )
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# CLI quick-test (paper trade simulation)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    from market_scanner import BinRange, WeatherMarket
    from edge_calculator import evaluate_market

    fake_market = WeatherMarket(
        condition_id="0xTEST",
        market_slug="test-market",
        question="Will the high in London be above 25°C on July 1?",
        clob_token_ids=["tok_yes", "tok_no"],
        tick_size=0.01,
        neg_risk=False,
        city="London",
        target_date=date(2025, 7, 1),
        bin_range=BinRange(low=25, high=None, unit="C", label=">25°C"),
        outcome_index=0,
        mid_price=0.40,
        best_bid=0.39,
        best_ask=0.41,
        volume_usd=6000.0,
        liquidity_usd=1800.0,
    )

    trader = Trader()
    edge_result = evaluate_market(fake_market, model_prob=0.62, bankroll=trader.bankroll)
    print(edge_result.one_liner())

    record = trader.execute(fake_market, edge_result)
    if record:
        print(f"\nTrade: {record.id} | status={record.status} | fill=${record.fill_usd:.2f}")
    print("\n" + trader.daily_summary())
