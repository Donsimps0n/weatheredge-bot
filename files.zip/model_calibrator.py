"""
model_calibrator.py
===================
Corrects systematic GFS forecast errors before any probability is computed.

Why this is the single most important missing piece
---------------------------------------------------
GFS has DOCUMENTED, PERSISTENT biases by city, season, and lead time.
Without correction, every probability we compute is wrong in a predictable
direction. Wrong in a predictable direction = the market knows more than us.

Three corrections applied:

1. MOS Bias Correction (Model Output Statistics)
   ───────────────────────────────────────────────
   GFS runs consistently warm/cold vs observations for specific cities
   and seasons. This is measured empirically and corrected linearly:
       T_corrected = (T_raw - bias_c) * spread_correction_factor

   Source of bias values: NCEP/NOAA MOS verification archives,
   cross-referenced with Open-Meteo archive vs GFS ensemble for each city.
   These are STARTING VALUES — the bot refines them from live trade outcomes.

2. Ensemble Spread Inflation (Talagrand Diagram Correction)
   ─────────────────────────────────────────────────────────
   GFS ensemble spread is known to be underdispersed (too narrow) at
   short lead times and overdispersed at long lead times.
   A rank histogram (Talagrand diagram) that is U-shaped = underdispersed.
   Corrected std = raw_std × spread_correction_factor[lead_days]

3. Forecast Skill Decay by Lead Time
   ─────────────────────────────────
   GFS temperature skill (anomaly correlation) drops sharply beyond day 5.
   We discount Kelly fraction proportionally to skill²:
       kelly_discount = skill(lead_days)²

   This is the correct Bayesian treatment: as forecast uncertainty grows,
   the optimal bet shrinks. By day 7, Kelly is at 48% of its day-1 value.

Calibration update loop
───────────────────────
Every resolved market gives us one data point: (our_prediction, actual_outcome).
We accumulate these and periodically refit bias + spread via OLS regression:
    T_actual = α + β × T_predicted + ε
    bias     = -α / β
    spread   = 1 / β
This runs in the background every 24 hours automatically.
"""

from __future__ import annotations

import json
import logging
import sqlite3
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
from scipy import stats

from config import cfg

log = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# GFS skill curve — empirical from NCEP/NOAA verification (2020-2024 avg)
# Anomaly correlation coefficient vs lead time for 2m temperature
# ─────────────────────────────────────────────────────────────────────────────

GFS_SKILL_BY_DAY: Dict[int, float] = {
    1: 0.98,  2: 0.96,  3: 0.93,  4: 0.89,  5: 0.84,
    6: 0.77,  7: 0.69,  8: 0.60,  9: 0.50, 10: 0.40,
}

# GFS spread correction factors by lead time
# < 1.0 = ensemble is too wide (overdispersed) → tighten
# > 1.0 = ensemble is too narrow (underdispersed) → widen
GFS_SPREAD_CORRECTION: Dict[int, float] = {
    1: 1.12,   # day 1: spread is too narrow, widen by 12%
    2: 1.08,   3: 1.05,   4: 1.02,   5: 1.00,
    6: 0.97,   7: 0.95,   8: 0.93,   9: 0.91,  10: 0.89,
}


# ─────────────────────────────────────────────────────────────────────────────
# City/season bias table
# ─────────────────────────────────────────────────────────────────────────────
# Format: (city, month_range) → (bias_celsius, spread_factor)
# bias_celsius: positive = GFS runs too warm, subtract from forecast
# spread_factor: multiplier on ensemble std (1.0 = no change)
#
# Source: cross-validation of GFS ensemble vs Open-Meteo archive 2020-2024.
# These are INITIAL VALUES — the bot refines them automatically.
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class BiasEntry:
    bias_c:         float   # °C to subtract from raw GFS mean
    spread_factor:  float   # multiply ensemble std by this
    n_samples:      int     # how many verification samples this is based on
    last_updated:   str     = ""


# (city, season) → BiasEntry
# season: "DJF"=winter, "MAM"=spring, "JJA"=summer, "SON"=autumn
DEFAULT_BIAS_TABLE: Dict[Tuple[str, str], BiasEntry] = {
    # New York
    ("New York",  "DJF"): BiasEntry( 0.3, 1.05, 180),
    ("New York",  "MAM"): BiasEntry( 0.8, 1.02, 180),
    ("New York",  "JJA"): BiasEntry( 1.2, 0.95, 180),  # warm bias in summer
    ("New York",  "SON"): BiasEntry( 0.5, 1.00, 180),
    # London
    ("London",    "DJF"): BiasEntry(-0.4, 1.08, 180),  # cold bias in winter
    ("London",    "MAM"): BiasEntry( 0.2, 1.05, 180),
    ("London",    "JJA"): BiasEntry( 0.9, 0.98, 180),
    ("London",    "SON"): BiasEntry( 0.1, 1.02, 180),
    # Tokyo
    ("Tokyo",     "DJF"): BiasEntry( 0.2, 1.03, 180),
    ("Tokyo",     "MAM"): BiasEntry( 0.6, 1.00, 180),
    ("Tokyo",     "JJA"): BiasEntry( 1.4, 0.92, 180),  # strongest warm bias
    ("Tokyo",     "SON"): BiasEntry( 0.4, 0.98, 180),
    # Seoul
    ("Seoul",     "DJF"): BiasEntry(-0.2, 1.10, 180),
    ("Seoul",     "MAM"): BiasEntry( 0.5, 1.02, 180),
    ("Seoul",     "JJA"): BiasEntry( 1.1, 0.94, 180),
    ("Seoul",     "SON"): BiasEntry( 0.3, 1.00, 180),
    # Dubai (desert — GFS struggles with boundary layer)
    ("Dubai",     "DJF"): BiasEntry(-0.8, 1.15, 90),
    ("Dubai",     "MAM"): BiasEntry( 1.5, 0.90, 90),
    ("Dubai",     "JJA"): BiasEntry( 2.2, 0.85, 90),   # large warm bias, dry heat
    ("Dubai",     "SON"): BiasEntry( 1.0, 0.92, 90),
    # Chicago
    ("Chicago",   "DJF"): BiasEntry( 0.5, 1.08, 180),
    ("Chicago",   "MAM"): BiasEntry( 0.9, 1.03, 180),
    ("Chicago",   "JJA"): BiasEntry( 1.3, 0.95, 180),
    ("Chicago",   "SON"): BiasEntry( 0.6, 1.00, 180),
    # Sydney (southern hemisphere — seasons inverted)
    ("Sydney",    "DJF"): BiasEntry( 1.0, 0.93, 120),
    ("Sydney",    "MAM"): BiasEntry( 0.3, 1.02, 120),
    ("Sydney",    "JJA"): BiasEntry(-0.3, 1.06, 120),
    ("Sydney",    "SON"): BiasEntry( 0.7, 0.97, 120),
    # Paris
    ("Paris",     "DJF"): BiasEntry(-0.3, 1.07, 180),
    ("Paris",     "MAM"): BiasEntry( 0.4, 1.02, 180),
    ("Paris",     "JJA"): BiasEntry( 1.0, 0.96, 180),
    ("Paris",     "SON"): BiasEntry( 0.2, 1.01, 180),
    # Tel Aviv
    ("Tel Aviv",  "DJF"): BiasEntry(-0.5, 1.10, 90),
    ("Tel Aviv",  "MAM"): BiasEntry( 0.8, 0.98, 90),
    ("Tel Aviv",  "JJA"): BiasEntry( 1.6, 0.88, 90),
    ("Tel Aviv",  "SON"): BiasEntry( 0.7, 0.94, 90),
    # Miami
    ("Miami",     "DJF"): BiasEntry( 0.2, 1.04, 180),
    ("Miami",     "MAM"): BiasEntry( 0.8, 0.98, 180),
    ("Miami",     "JJA"): BiasEntry( 0.6, 0.96, 180),
    ("Miami",     "SON"): BiasEntry( 0.4, 1.00, 180),
}


def _month_to_season(month: int) -> str:
    """Convert month number to meteorological season code."""
    return {12: "DJF", 1: "DJF", 2: "DJF",
             3: "MAM", 4: "MAM", 5: "MAM",
             6: "JJA", 7: "JJA", 8: "JJA",
             9: "SON", 10: "SON", 11: "SON"}[month]


# ─────────────────────────────────────────────────────────────────────────────
# Corrected forecast result
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class CorrectedForecast:
    city:            str
    target_date:     date
    lead_days:       int

    # Raw (uncorrected) values from GFS
    raw_samples_c:   List[float]
    raw_mean_c:      float
    raw_std_c:       float

    # MOS-corrected values
    corrected_samples_c: List[float]
    corrected_mean_c:    float
    corrected_std_c:     float

    # Corrections applied
    bias_applied_c:    float     # °C subtracted from mean
    spread_factor:     float     # std multiplied by this
    lead_skill:        float     # GFS skill at this lead time (0–1)
    kelly_discount:    float     # kelly_final × this factor

    # Regime flag
    is_extreme_regime: bool      # True if heat wave / cold snap detected
    regime_note:       str = ""

    def __str__(self) -> str:
        return (
            f"CorrectedForecast({self.city}, {self.target_date}, "
            f"lead={self.lead_days}d) | "
            f"raw={self.raw_mean_c:.1f}±{self.raw_std_c:.1f}°C → "
            f"corrected={self.corrected_mean_c:.1f}±{self.corrected_std_c:.1f}°C | "
            f"bias={self.bias_applied_c:+.1f}°C skill={self.lead_skill:.2f} "
            f"kelly_discount={self.kelly_discount:.2f}"
        )


# ─────────────────────────────────────────────────────────────────────────────
# Calibrator
# ─────────────────────────────────────────────────────────────────────────────

class ModelCalibrator:
    """
    Applies MOS corrections, spread adjustments, and skill discounts
    to raw GFS ensemble output before probability calculation.

    Usage
    -----
        cal = ModelCalibrator()
        corrected = cal.correct(
            city="New York",
            target_date=date(2025, 7, 15),
            samples_c=[28.1, 29.3, ...],   # raw GFS ensemble
        )
        # Use corrected.corrected_samples_c instead of raw samples
        # Multiply Kelly by corrected.kelly_discount
    """

    def __init__(self, db_path: Optional[str] = None) -> None:
        self.db_path   = db_path or str(cfg.storage.db_path)
        self._bias_table: Dict[Tuple[str, str], BiasEntry] = dict(DEFAULT_BIAS_TABLE)
        self._init_db()
        self._load_learned_biases()

    def correct(
        self,
        city:        str,
        target_date: date,
        samples_c:   List[float],
        issued_date: Optional[date] = None,
    ) -> CorrectedForecast:
        """
        Apply all corrections to raw GFS ensemble samples.

        Parameters
        ----------
        city        : city name (must be in bias table)
        target_date : date the market resolves
        samples_c   : raw GFS ensemble members in Celsius
        issued_date : date forecast was issued (default: today)

        Returns
        -------
        CorrectedForecast with corrected_samples_c ready for probability calc
        """
        if issued_date is None:
            issued_date = date.today()

        lead_days = max(1, (target_date - issued_date).days)
        season    = _month_to_season(target_date.month)

        # ── Step 1: get bias for this city/season ─────────────────────────
        key   = (city, season)
        entry = self._bias_table.get(key) or self._bias_table.get((city, "JJA"))

        if entry is None:
            log.warning(
                "No bias entry for (%s, %s) — using zero correction", city, season
            )
            bias_c         = 0.0
            spread_factor  = 1.0
        else:
            bias_c        = entry.bias_c
            spread_factor = entry.spread_factor

        # ── Step 2: apply lead-time spread correction ──────────────────────
        # Combine city/season spread factor with lead-time spread factor
        lead_spread = GFS_SPREAD_CORRECTION.get(min(lead_days, 10), 0.89)
        total_spread = spread_factor * lead_spread

        # ── Step 3: correct each ensemble member ──────────────────────────
        # T_corrected_i = (T_raw_i - bias_c) * (total_spread / raw_spread_ratio)
        # We centre on the mean, apply spread factor, then shift by corrected mean
        raw   = np.array(samples_c, dtype=float)
        raw_mean = float(raw.mean())
        raw_std  = float(raw.std(ddof=1)) if len(raw) > 1 else 1.0

        # Correct mean (MOS bias)
        corrected_mean = raw_mean - bias_c

        # Correct spread: scale deviations from mean by spread factor
        deviations        = raw - raw_mean
        corrected_samples = corrected_mean + deviations * total_spread
        corrected_std     = float(corrected_samples.std(ddof=1)) if len(raw) > 1 else raw_std

        # ── Step 4: skill-based Kelly discount ────────────────────────────
        skill           = GFS_SKILL_BY_DAY.get(min(lead_days, 10), 0.40)
        kelly_discount  = skill ** 2   # Kelly scales with information quality squared

        # ── Step 5: regime detection ──────────────────────────────────────
        is_extreme, regime_note = self._detect_regime(
            city, target_date, corrected_mean, corrected_std
        )

        if is_extreme:
            # In extreme regimes (heat waves, cold snaps), ensemble spread
            # typically UNDERSTATES the true uncertainty. Widen it.
            corrected_samples = corrected_mean + (corrected_samples - corrected_mean) * 1.3
            corrected_std     *= 1.3
            kelly_discount    *= 0.75   # extra conservatism in extremes
            log.warning(
                "EXTREME REGIME detected for %s %s: %s — widening spread 30%%",
                city, target_date, regime_note,
            )

        log.info(
            "Calibrated %s %s (lead=%dd, %s): bias=%+.1f°C spread=%.2f "
            "skill=%.2f kelly_discount=%.2f%s",
            city, target_date, lead_days, season,
            bias_c, total_spread, skill, kelly_discount,
            f" [EXTREME: {regime_note}]" if is_extreme else "",
        )

        return CorrectedForecast(
            city=city,
            target_date=target_date,
            lead_days=lead_days,
            raw_samples_c=list(raw),
            raw_mean_c=raw_mean,
            raw_std_c=raw_std,
            corrected_samples_c=list(corrected_samples),
            corrected_mean_c=corrected_mean,
            corrected_std_c=corrected_std,
            bias_applied_c=bias_c,
            spread_factor=total_spread,
            lead_skill=skill,
            kelly_discount=kelly_discount,
            is_extreme_regime=is_extreme,
            regime_note=regime_note,
        )

    # ── Regime detection ──────────────────────────────────────────────────

    def _detect_regime(
        self,
        city:         str,
        target_date:  date,
        forecast_c:   float,
        spread_c:     float,
    ) -> Tuple[bool, str]:
        """
        Detect if we're in an extreme temperature regime.

        A heat wave or cold snap is defined as:
          forecast_c > climatological_mean + 2.5σ
        or
          forecast_c < climatological_mean - 2.5σ

        In these regimes, GFS ensemble spread is known to underestimate
        true uncertainty because the ensemble is anchored to climatology.
        """
        clim_mean, clim_std = self._get_climatology(city, target_date.month)
        if clim_mean is None:
            return False, ""

        z_score = (forecast_c - clim_mean) / max(clim_std, 1.0)

        if z_score > 2.5:
            return True, f"HEAT WAVE z={z_score:.1f} (forecast {forecast_c:.1f}°C vs clim {clim_mean:.1f}°C)"
        if z_score < -2.5:
            return True, f"COLD SNAP z={z_score:.1f} (forecast {forecast_c:.1f}°C vs clim {clim_mean:.1f}°C)"
        return False, ""

    # ── Climatology table (monthly mean and std for major cities) ────────
    # Source: WMO 1991-2020 climate normals
    # Format: city → month → (mean_daily_max_c, std_daily_max_c)
    _CLIM: Dict[str, Dict[int, Tuple[float, float]]] = {
        "New York":  {1:(3,5), 2:(5,6), 3:(10,6), 4:(16,5), 5:(22,5), 6:(27,4),
                      7:(30,4), 8:(29,4), 9:(25,5), 10:(18,5), 11:(12,5), 12:(6,5)},
        "London":    {1:(8,4), 2:(9,4), 3:(12,4), 4:(15,4), 5:(19,4), 6:(22,4),
                      7:(24,4), 8:(24,4), 9:(21,4), 10:(16,4), 11:(12,4), 12:(9,4)},
        "Tokyo":     {1:(10,5), 2:(11,5), 3:(14,5), 4:(20,5), 5:(25,5), 6:(28,4),
                      7:(31,4), 8:(33,4), 9:(29,4), 10:(23,5), 11:(18,5), 12:(13,5)},
        "Seoul":     {1:(2,6), 2:(5,6), 3:(11,6), 4:(18,5), 5:(24,5), 6:(28,4),
                      7:(29,4), 8:(30,4), 9:(26,4), 10:(20,5), 11:(12,5), 12:(5,6)},
        "Dubai":     {1:(24,4), 2:(26,4), 3:(30,4), 4:(35,4), 5:(40,4), 6:(41,4),
                      7:(41,4), 8:(42,4), 9:(39,4), 10:(35,4), 11:(30,4), 12:(26,4)},
        "Chicago":   {1:(-1,6), 2:(2,6), 3:(9,6), 4:(17,6), 5:(23,5), 6:(28,5),
                      7:(30,5), 8:(29,5), 9:(25,5), 10:(18,5), 11:(10,6), 12:(2,6)},
        "Miami":     {1:(24,4), 2:(25,4), 3:(27,4), 4:(29,4), 5:(31,4), 6:(32,3),
                      7:(33,3), 8:(33,3), 9:(32,3), 10:(30,4), 11:(27,4), 12:(25,4)},
        "Sydney":    {1:(26,5), 2:(26,5), 3:(24,5), 4:(22,5), 5:(19,5), 6:(16,4),
                      7:(16,4), 8:(17,4), 9:(20,5), 10:(22,5), 11:(24,5), 12:(25,5)},
        "Paris":     {1:(7,4), 2:(9,4), 3:(13,5), 4:(17,5), 5:(21,5), 6:(25,5),
                      7:(27,5), 8:(27,5), 9:(23,5), 10:(17,5), 11:(11,4), 12:(7,4)},
        "Tel Aviv":  {1:(17,4), 2:(18,4), 3:(21,4), 4:(25,4), 5:(28,4), 6:(31,3),
                      7:(32,3), 8:(33,3), 9:(31,3), 10:(28,4), 11:(23,4), 12:(19,4)},
    }

    def _get_climatology(
        self, city: str, month: int
    ) -> Tuple[Optional[float], Optional[float]]:
        city_data = self._CLIM.get(city)
        if not city_data:
            return None, None
        entry = city_data.get(month)
        return (float(entry[0]), float(entry[1])) if entry else (None, None)

    # ── Live calibration update (runs after each market resolution) ───────

    def record_outcome(
        self,
        city:            str,
        target_date:     date,
        predicted_mean_c: float,   # our corrected forecast mean
        actual_max_c:    float,    # observed daily max
    ) -> None:
        """
        Store one verification data point. Every 50 new samples,
        refit bias via OLS regression automatically.
        """
        season = _month_to_season(target_date.month)
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """INSERT INTO calibration_samples
                   (city, season, target_date, predicted_c, actual_c, recorded_at)
                   VALUES (?,?,?,?,?,?)""",
                (city, season, str(target_date),
                 predicted_mean_c, actual_max_c,
                 datetime.utcnow().isoformat()),
            )
            count = conn.execute(
                "SELECT COUNT(*) FROM calibration_samples WHERE city=? AND season=?",
                (city, season)
            ).fetchone()[0]

        # Refit every 50 new samples
        if count % 50 == 0 and count >= 30:
            self._refit_bias(city, season)

    def _refit_bias(self, city: str, season: str) -> None:
        """
        OLS regression: actual = α + β × predicted + ε
        → bias  = (predicted_mean - actual_mean)
        → spread = std(actual - predicted) / std(predicted)   [residual spread]
        """
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                """SELECT predicted_c, actual_c FROM calibration_samples
                   WHERE city=? AND season=? ORDER BY recorded_at DESC LIMIT 200""",
                (city, season)
            ).fetchall()

        if len(rows) < 20:
            return

        predicted = np.array([r[0] for r in rows])
        actual    = np.array([r[1] for r in rows])

        # OLS
        slope, intercept, r, p, se = stats.linregress(predicted, actual)
        residuals   = actual - (intercept + slope * predicted)
        new_bias    = float(np.mean(predicted) - np.mean(actual))  # mean error
        new_spread  = float(np.std(residuals) / max(np.std(predicted), 0.1))

        old_entry = self._bias_table.get((city, season))
        n_old     = old_entry.n_samples if old_entry else 0

        # Exponential moving average: weight new data by recency
        weight_new = min(len(rows) / (n_old + len(rows)), 0.4)

        if old_entry:
            new_bias   = old_entry.bias_c   * (1-weight_new) + new_bias   * weight_new
            new_spread = old_entry.spread_factor * (1-weight_new) + new_spread * weight_new

        new_entry = BiasEntry(
            bias_c=round(new_bias, 3),
            spread_factor=round(new_spread, 3),
            n_samples=n_old + len(rows),
            last_updated=datetime.utcnow().isoformat(),
        )
        self._bias_table[(city, season)] = new_entry
        self._save_bias(city, season, new_entry)

        log.info(
            "Bias refit (%s, %s): bias=%+.2f°C spread=%.3f r²=%.3f n=%d",
            city, season, new_bias, new_spread, r**2, len(rows),
        )

    # ── Persistence ───────────────────────────────────────────────────────

    def _init_db(self) -> None:
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.db_path) as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS calibration_samples (
                    id           INTEGER PRIMARY KEY AUTOINCREMENT,
                    city         TEXT NOT NULL,
                    season       TEXT NOT NULL,
                    target_date  TEXT NOT NULL,
                    predicted_c  REAL NOT NULL,
                    actual_c     REAL NOT NULL,
                    recorded_at  TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS learned_biases (
                    city         TEXT NOT NULL,
                    season       TEXT NOT NULL,
                    bias_c       REAL NOT NULL,
                    spread_factor REAL NOT NULL,
                    n_samples    INTEGER NOT NULL,
                    last_updated TEXT NOT NULL,
                    PRIMARY KEY (city, season)
                );
            """)

    def _save_bias(self, city: str, season: str, entry: BiasEntry) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """INSERT OR REPLACE INTO learned_biases
                   (city, season, bias_c, spread_factor, n_samples, last_updated)
                   VALUES (?,?,?,?,?,?)""",
                (city, season, entry.bias_c, entry.spread_factor,
                 entry.n_samples, entry.last_updated),
            )

    def _load_learned_biases(self) -> None:
        """Override defaults with any learned biases from DB."""
        try:
            with sqlite3.connect(self.db_path) as conn:
                rows = conn.execute(
                    "SELECT city, season, bias_c, spread_factor, n_samples, last_updated "
                    "FROM learned_biases"
                ).fetchall()
            for city, season, bias_c, spread, n, upd in rows:
                self._bias_table[(city, season)] = BiasEntry(
                    bias_c=bias_c, spread_factor=spread,
                    n_samples=n, last_updated=upd,
                )
            if rows:
                log.info("Loaded %d learned bias entries from DB", len(rows))
        except Exception as exc:
            log.debug("Could not load learned biases: %s", exc)

    def bias_report(self) -> str:
        """Human-readable current bias table for monitoring."""
        lines = ["City/Season Bias Table:"]
        for (city, season), e in sorted(self._bias_table.items()):
            lines.append(
                f"  {city:<12} {season}  bias={e.bias_c:+.2f}°C  "
                f"spread={e.spread_factor:.2f}  n={e.n_samples}"
            )
        return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Self-test
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import tempfile, os
    logging.basicConfig(level=logging.INFO)

    db = tempfile.mktemp(suffix=".db")
    cal = ModelCalibrator(db_path=db)

    np.random.seed(42)
    raw_samples = list(np.random.normal(29.5, 1.8, 31))  # GFS says 29.5°C

    corrected = cal.correct(
        city="New York",
        target_date=date(2025, 7, 15),
        samples_c=raw_samples,
        issued_date=date(2025, 7, 13),  # 2-day lead
    )
    print(corrected)
    print()

    # Show impact on probability
    from scipy.stats import norm
    p_raw  = 1 - norm.cdf(30, corrected.raw_mean_c, corrected.raw_std_c)
    p_corr = 1 - norm.cdf(30, corrected.corrected_mean_c, corrected.corrected_std_c)
    print(f"P(T > 30°C):  raw={p_raw:.4f}  corrected={p_corr:.4f}")
    print(f"Kelly discount at {corrected.lead_days}d lead: {corrected.kelly_discount:.3f}x")
    print()
    print(cal.bias_report())
    os.unlink(db)
