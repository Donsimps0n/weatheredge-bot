"""
forecast_fetcher.py
===================
Fetches probabilistic temperature forecasts from multiple sources and
combines them into a unified ForecastResult for a given city + date.

Primary source: Open-Meteo GFS Ensemble API (free, 31 members)
  - Endpoint: https://ensemble-api.open-meteo.com/v1/ensemble
  - Provides 31 independent GFS ensemble members → ideal for probability
  - Each member gives an hourly temperature trace for the target day
  - We compute the daily max from each member → 31 max-temp samples
  - The empirical distribution of those 31 samples IS our probability estimate

Optional consensus fallback (improves confidence when open-meteo is uncertain):
  - Tomorrow.io  (point forecast + percentiles)
  - OpenWeatherMap (deterministic forecast — treated as a single pseudo-member)

Historical verification:
  - Open-Meteo archive API returns actual observed temperatures for past dates
  - Used by backtester.py to check if our forecasts were calibrated

Why ensemble spread matters for trading
---------------------------------------
  * High ensemble spread (high σ) → market is hard to price → markets often
    mis-price because human traders anchor to the deterministic forecast.
  * Low spread (low σ)  → the outcome is nearly certain → only trade if the
    market price is far from 1.0 or 0.0.
  * Best edges appear when: our ensemble is TIGHT but the market is WIDE, OR
    our ensemble confidently shifts the probability but the market hasn't moved.

Caching
-------
  Forecasts are cached per (city, date) with a TTL of FORECAST_REFRESH_SECONDS.
  Re-fetching within that window returns the cached result instantly.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from typing import Dict, List, Optional, Tuple

import numpy as np
import requests
from cachetools import TTLCache
from tenacity import retry, stop_after_attempt, wait_exponential

from config import cfg, get_city_coords

log = logging.getLogger(__name__)

# Cache: keyed by (city, date_iso_string), TTL = forecast refresh interval
_forecast_cache: TTLCache = TTLCache(
    maxsize=200,
    ttl=cfg.scheduler.forecast_refresh_seconds,
)


# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------

@dataclass
class ForecastResult:
    """
    All forecast information for one city on one date.

    The core output is `daily_max_samples` — a list of temperature values
    (in °C) representing the spread of outcomes from the ensemble.
    probability_calculator.py turns this into bin probabilities.
    """
    city:             str
    target_date:      date
    source:           str             # e.g. "open_meteo_gfs_ensemble"
    model_run_time:   Optional[datetime]  # when the model was initialised

    # ── Core ensemble data ────────────────────────────────────────────────
    # One value per ensemble member = the predicted daily maximum temp in °C
    daily_max_samples: List[float]    # len = n_members (typically 31)

    # ── Summary stats (pre-computed for convenience) ───────────────────────
    mean_max_c:       float           # mean daily max (°C)
    std_max_c:        float           # std dev of daily max
    p10_c:            float           # 10th percentile
    p25_c:            float           # 25th percentile
    p50_c:            float           # median
    p75_c:            float           # 75th percentile
    p90_c:            float           # 90th percentile

    # ── Consensus data (from secondary APIs, may be empty) ─────────────────
    consensus_means_c: List[float] = field(default_factory=list)
    consensus_sources: List[str]   = field(default_factory=list)

    # ── Metadata ──────────────────────────────────────────────────────────
    fetched_at:       datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    is_historical:    bool = False    # True when fetched from archive (actual obs)

    @property
    def n_members(self) -> int:
        return len(self.daily_max_samples)

    @property
    def all_means_c(self) -> List[float]:
        """Ensemble mean + any consensus sources, for meta-model weighting."""
        return [self.mean_max_c] + list(self.consensus_means_c)

    def mean_max_f(self) -> float:
        return self.mean_max_c * 9 / 5 + 32

    def to_fahrenheit_samples(self) -> List[float]:
        return [t * 9 / 5 + 32 for t in self.daily_max_samples]

    def confidence_note(self) -> str:
        """Human-readable note about forecast confidence."""
        spread = self.p90_c - self.p10_c
        if spread < 3:
            return f"HIGH confidence (10-90 spread = {spread:.1f}°C)"
        elif spread < 7:
            return f"MODERATE confidence (10-90 spread = {spread:.1f}°C)"
        else:
            return f"LOW confidence (10-90 spread = {spread:.1f}°C)"

    def __str__(self) -> str:
        return (
            f"ForecastResult({self.city}, {self.target_date}) | "
            f"mean={self.mean_max_c:.1f}°C ± {self.std_max_c:.1f} | "
            f"n={self.n_members} | {self.confidence_note()}"
        )


def _make_stats(samples: List[float]) -> Tuple[float, float, float, float, float, float, float]:
    """Return (mean, std, p10, p25, p50, p75, p90) from a list of floats."""
    arr = np.array(samples, dtype=float)
    return (
        float(np.mean(arr)),
        float(np.std(arr, ddof=1)) if len(arr) > 1 else 0.0,
        float(np.percentile(arr, 10)),
        float(np.percentile(arr, 25)),
        float(np.percentile(arr, 50)),
        float(np.percentile(arr, 75)),
        float(np.percentile(arr, 90)),
    )


# ---------------------------------------------------------------------------
# Open-Meteo Ensemble fetcher  (primary source)
# ---------------------------------------------------------------------------

class OpenMeteoEnsembleFetcher:
    """
    Fetches 31-member GFS ensemble from Open-Meteo's ensemble API.

    For each ensemble member, the API returns hourly temperature_2m traces.
    We extract the maximum over the local calendar day to get daily high.

    Free, no API key, ~31 members, updated every 6 hours.
    Docs: https://open-meteo.com/en/docs/ensemble-api
    """

    ENSEMBLE_URL  = cfg.weather.open_meteo_ensemble_url
    ARCHIVE_URL   = cfg.weather.open_meteo_archive_url
    FORECAST_URL  = cfg.weather.open_meteo_forecast_url

    ENSEMBLE_MODELS = [
        "gfs_seamless",          # primary — 31 members
        # "icon_seamless",       # optional backup (51 members, European)
        # "ecmwf_ifs04",        # optional (51 members, needs subscription)
    ]

    def __init__(self) -> None:
        self.session = requests.Session()
        self.session.headers["User-Agent"] = "polymarket-weather-bot/1.0"

    @retry(stop=stop_after_attempt(4),
           wait=wait_exponential(multiplier=1, min=2, max=60))
    def _get(self, url: str, params: dict) -> dict:
        resp = self.session.get(url, params=params, timeout=30)
        resp.raise_for_status()
        return resp.json()

    def fetch(self, city: str, target_date: date) -> Optional[ForecastResult]:
        """
        Main entry: returns ForecastResult or None if all attempts fail.

        If target_date is in the past, fetches from the archive API (actual obs).
        If target_date is today or future, fetches ensemble forecast.
        """
        lat, lon = get_city_coords(city)
        today = date.today()

        if target_date < today:
            return self._fetch_historical(city, lat, lon, target_date)
        else:
            return self._fetch_ensemble(city, lat, lon, target_date)

    # ── Ensemble forecast (present / future) ─────────────────────────────

    def _fetch_ensemble(
        self, city: str, lat: float, lon: float, target_date: date
    ) -> Optional[ForecastResult]:
        """
        Pull 31-member GFS ensemble and compute daily max distribution.
        """
        # How many days ahead is the target?
        days_ahead = (target_date - date.today()).days

        # Open-Meteo ensemble goes out ~16 days; GFS goes out 16+ days
        if days_ahead > 16:
            log.warning(
                "%s: target date %s is %d days out — "
                "ensemble reliability degrades past ~10 days",
                city, target_date, days_ahead
            )

        # Build list of member variable names
        # Open-Meteo exposes each member as "temperature_2m_member{nn}"
        members = [f"temperature_2m_member{str(i).zfill(2)}" for i in range(31)]

        params = {
            "latitude":   lat,
            "longitude":  lon,
            "hourly":     ",".join(members),
            "models":     "gfs_seamless",
            "temperature_unit": "celsius",
            "timezone":   "auto",
            "start_date": target_date.isoformat(),
            "end_date":   target_date.isoformat(),
        }

        try:
            data = self._get(self.ENSEMBLE_URL, params)
        except Exception as exc:
            log.error("Open-Meteo ensemble fetch failed for %s %s: %s",
                      city, target_date, exc)
            return None

        hourly = data.get("hourly", {})
        model_run_time = self._parse_model_time(data)

        daily_maxes: List[float] = []
        for member in members:
            temps = hourly.get(member)
            if temps and any(t is not None for t in temps):
                valid = [t for t in temps if t is not None]
                if valid:
                    daily_maxes.append(max(valid))

        if len(daily_maxes) < cfg.weather.min_ensemble_members:
            log.warning(
                "Too few ensemble members for %s %s: got %d, need %d",
                city, target_date, len(daily_maxes), cfg.weather.min_ensemble_members
            )
            return None

        mean, std, p10, p25, p50, p75, p90 = _make_stats(daily_maxes)

        log.info(
            "Ensemble: %s %s | n=%d | mean=%.1f°C ± %.1f | "
            "p10=%.1f p50=%.1f p90=%.1f",
            city, target_date, len(daily_maxes), mean, std, p10, p50, p90
        )

        return ForecastResult(
            city=city,
            target_date=target_date,
            source="open_meteo_gfs_ensemble",
            model_run_time=model_run_time,
            daily_max_samples=daily_maxes,
            mean_max_c=mean,
            std_max_c=std,
            p10_c=p10,
            p25_c=p25,
            p50_c=p50,
            p75_c=p75,
            p90_c=p90,
        )

    # ── Historical / archive ───────────────────────────────────────────────

    def _fetch_historical(
        self, city: str, lat: float, lon: float, target_date: date
    ) -> Optional[ForecastResult]:
        """
        Fetch actual observed daily maximum temperature for a past date.
        Returns a ForecastResult with n=1 sample (the truth) and std=0.
        Used by backtester to compute realised outcome.
        """
        params = {
            "latitude":   lat,
            "longitude":  lon,
            "daily":      "temperature_2m_max",
            "temperature_unit": "celsius",
            "timezone":   "auto",
            "start_date": target_date.isoformat(),
            "end_date":   target_date.isoformat(),
        }
        try:
            data = self._get(self.ARCHIVE_URL, params)
        except Exception as exc:
            log.error("Archive fetch failed for %s %s: %s", city, target_date, exc)
            return None

        daily = data.get("daily", {})
        maxes = daily.get("temperature_2m_max", [])
        if not maxes or maxes[0] is None:
            log.warning("No archive data for %s on %s", city, target_date)
            return None

        obs_max = float(maxes[0])
        mean, std, p10, p25, p50, p75, p90 = _make_stats([obs_max])

        return ForecastResult(
            city=city,
            target_date=target_date,
            source="open_meteo_archive_observed",
            model_run_time=None,
            daily_max_samples=[obs_max],
            mean_max_c=mean,
            std_max_c=0.0,
            p10_c=obs_max,
            p25_c=obs_max,
            p50_c=obs_max,
            p75_c=obs_max,
            p90_c=obs_max,
            is_historical=True,
        )

    def fetch_past_ensemble(
        self, city: str, target_date: date
    ) -> Optional[ForecastResult]:
        """
        Fetch what the GFS ENSEMBLE predicted N days ago for target_date.
        Used by backtester to replay model forecasts as they were at trade time.

        Open-Meteo's ensemble archive goes back ~6 months.
        We simulate a forecast issued 1 day before the target date.
        """
        lat, lon = get_city_coords(city)
        forecast_issue_date = target_date - timedelta(days=1)

        members = [f"temperature_2m_member{str(i).zfill(2)}" for i in range(31)]
        params = {
            "latitude":   lat,
            "longitude":  lon,
            "hourly":     ",".join(members),
            "models":     "gfs_seamless",
            "temperature_unit": "celsius",
            "timezone":   "auto",
            "start_date": target_date.isoformat(),
            "end_date":   target_date.isoformat(),
            # Open-Meteo doesn't support historical forecast runs directly;
            # we use the archive as a proxy here.
            # For production, store real-time forecasts in SQLite as they arrive.
        }

        try:
            data = self._get(self.ENSEMBLE_URL, params)
        except Exception:
            # Fall back to archive if ensemble archive not available
            return self._fetch_historical(city, lat, lon, target_date)

        hourly = data.get("hourly", {})
        daily_maxes = []
        for member in members:
            temps = hourly.get(member)
            if temps:
                valid = [t for t in temps if t is not None]
                if valid:
                    daily_maxes.append(max(valid))

        if not daily_maxes:
            return self._fetch_historical(city, lat, lon, target_date)

        mean, std, p10, p25, p50, p75, p90 = _make_stats(daily_maxes)
        return ForecastResult(
            city=city,
            target_date=target_date,
            source="open_meteo_gfs_ensemble_archive",
            model_run_time=None,
            daily_max_samples=daily_maxes,
            mean_max_c=mean, std_max_c=std,
            p10_c=p10, p25_c=p25, p50_c=p50, p75_c=p75, p90_c=p90,
        )

    @staticmethod
    def _parse_model_time(data: dict) -> Optional[datetime]:
        """Try to extract model initialisation time from response metadata."""
        try:
            gen_time = data.get("generationtime_ms")
            if gen_time:
                return datetime.now(timezone.utc)  # best we can do without raw field
        except Exception:
            pass
        return None


# ---------------------------------------------------------------------------
# Tomorrow.io  (optional consensus)
# ---------------------------------------------------------------------------

class TomorrowIoFetcher:
    """
    Fetches Tomorrow.io hourly forecast — used as a secondary consensus model.
    Returns a single mean daily max (treated as one pseudo-ensemble member).
    """

    BASE = cfg.weather.tomorrow_io_base_url

    def __init__(self) -> None:
        self.api_key = cfg.weather.tomorrow_io_api_key
        self.session = requests.Session()

    def fetch_mean_max(self, city: str, target_date: date) -> Optional[float]:
        """Return mean daily max in °C, or None if unavailable."""
        if not self.api_key:
            return None
        lat, lon = get_city_coords(city)
        try:
            resp = self.session.get(
                f"{self.BASE}/weather/forecast",
                params={
                    "apikey":   self.api_key,
                    "location": f"{lat},{lon}",
                    "timesteps": "1h",
                    "units":    "metric",
                    "fields":   "temperature",
                    "startTime": datetime.combine(target_date, datetime.min.time()).isoformat() + "Z",
                    "endTime":   datetime.combine(target_date + timedelta(days=1), datetime.min.time()).isoformat() + "Z",
                },
                timeout=15,
            )
            resp.raise_for_status()
            data = resp.json()
            temps = [
                interval["values"]["temperature"]
                for interval in data.get("timelines", [{}])[0].get("intervals", [])
                if "temperature" in interval.get("values", {})
            ]
            return max(temps) if temps else None
        except Exception as exc:
            log.debug("Tomorrow.io fetch failed for %s: %s", city, exc)
            return None


# ---------------------------------------------------------------------------
# OpenWeatherMap  (optional consensus)
# ---------------------------------------------------------------------------

class OpenWeatherFetcher:
    """
    Fetches OWM 5-day/3hr forecast — used as tertiary consensus.
    Deterministic; treated as one pseudo-member.
    """

    BASE = cfg.weather.openweather_base_url

    def __init__(self) -> None:
        self.api_key = cfg.weather.openweather_api_key
        self.session = requests.Session()

    def fetch_mean_max(self, city: str, target_date: date) -> Optional[float]:
        if not self.api_key:
            return None
        lat, lon = get_city_coords(city)
        try:
            resp = self.session.get(
                f"{self.BASE}/forecast",
                params={
                    "lat":   lat,
                    "lon":   lon,
                    "appid": self.api_key,
                    "units": "metric",
                    "cnt":   40,
                },
                timeout=15,
            )
            resp.raise_for_status()
            data = resp.json()
            temps = [
                entry["main"]["temp_max"]
                for entry in data.get("list", [])
                if datetime.utcfromtimestamp(entry["dt"]).date() == target_date
            ]
            return max(temps) if temps else None
        except Exception as exc:
            log.debug("OpenWeather fetch failed for %s: %s", city, exc)
            return None


# ---------------------------------------------------------------------------
# ForecastFetcher — public API
# ---------------------------------------------------------------------------

class ForecastFetcher:
    """
    Aggregates all forecast sources into a single ForecastResult.

    Usage
    -----
        fetcher = ForecastFetcher()
        result  = fetcher.get(city="New York", target_date=date(2025, 7, 4))
        print(result)
        # ForecastResult(New York, 2025-07-04) | mean=28.4°C ± 2.1 | n=31 ...
    """

    def __init__(self) -> None:
        self.ensemble  = OpenMeteoEnsembleFetcher()
        self.tomorrow  = TomorrowIoFetcher()
        self.owm       = OpenWeatherFetcher()

    def get(
        self,
        city: str,
        target_date: date,
        force_refresh: bool = False,
    ) -> Optional[ForecastResult]:
        """
        Return a ForecastResult for city × date, with consensus enrichment.
        Results are cached per (city, date) for FORECAST_REFRESH_SECONDS.
        """
        cache_key = f"{city}::{target_date.isoformat()}"

        if not force_refresh and cache_key in _forecast_cache:
            cached_fc = _forecast_cache[cache_key]
            log.debug("Returning cached forecast for %s %s", city, target_date)
            return cached_fc

        log.info("Fetching forecast: %s on %s", city, target_date)

        # ── Primary: GFS ensemble ─────────────────────────────────────────
        result = self.ensemble.fetch(city, target_date)
        if result is None:
            log.error("Primary ensemble fetch failed for %s %s — skipping", city, target_date)
            return None

        # ── Consensus: gather secondary sources ───────────────────────────
        consensus_means: List[float] = []
        consensus_sources: List[str] = []

        tomorrow_mean = self.tomorrow.fetch_mean_max(city, target_date)
        if tomorrow_mean is not None:
            consensus_means.append(tomorrow_mean)
            consensus_sources.append("tomorrow_io")
            log.debug("Tomorrow.io mean max for %s: %.1f°C", city, tomorrow_mean)

        owm_mean = self.owm.fetch_mean_max(city, target_date)
        if owm_mean is not None:
            consensus_means.append(owm_mean)
            consensus_sources.append("openweather")
            log.debug("OWM mean max for %s: %.1f°C", city, owm_mean)

        # Check consensus alignment
        if consensus_means:
            all_means = [result.mean_max_c] + consensus_means
            consensus_spread = max(all_means) - min(all_means)
            log.info(
                "Consensus for %s %s: sources=%s, spread=%.1f°C",
                city, target_date,
                ["open_meteo"] + consensus_sources,
                consensus_spread,
            )
            if consensus_spread > 5.0:
                log.warning(
                    "HIGH consensus disagreement for %s %s: %.1f°C spread. "
                    "Treat forecast with caution.",
                    city, target_date, consensus_spread,
                )

        # Enrich the result with consensus data
        from dataclasses import replace
        result = replace(
            result,
            consensus_means_c=consensus_means,
            consensus_sources=consensus_sources,
        )

        _forecast_cache[cache_key] = result
        log.info("Forecast ready: %s", result)
        return result

    def get_historical_actual(self, city: str, target_date: date) -> Optional[ForecastResult]:
        """
        Convenience: return the observed actual (archive) for a past date.
        Used by backtester to get ground truth.
        """
        return self.ensemble._fetch_historical(city, *get_city_coords(city), target_date)

    def get_past_ensemble(self, city: str, target_date: date) -> Optional[ForecastResult]:
        """
        Return what the ensemble was predicting for target_date (for backtesting).
        """
        return self.ensemble.fetch_past_ensemble(city, target_date)


# ---------------------------------------------------------------------------
# CLI quick-test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys
    logging.basicConfig(level=logging.DEBUG)

    fetcher = ForecastFetcher()
    city = sys.argv[1] if len(sys.argv) > 1 else "New York"
    target = date.today() + timedelta(days=2)

    result = fetcher.get(city=city, target_date=target)
    if result:
        print(f"\n{result}")
        print(f"  Samples (°C): {[round(x,1) for x in result.daily_max_samples]}")
        print(f"  In °F mean:   {result.mean_max_f():.1f}")
        print(f"  Sources:      {result.source}")
        if result.consensus_sources:
            print(f"  Consensus:    {result.consensus_sources} → {result.consensus_means_c}")
