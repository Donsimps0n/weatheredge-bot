"""
market_scanner.py
=================
Discovers active Polymarket weather/temperature markets via the Gamma API,
enriches them with live orderbook mid-prices from the CLOB, and returns
clean typed objects ready for the edge calculator.

Key design decisions
--------------------
* Uses a TTL cache (default 5 min) so rapid calls don't hammer the API.
* Parses temperature-bin markets by extracting city + date + bin range
  from the question text using regex heuristics — city matching against
  the configured cities list provides a secondary filter.
* Pulls mid-price from best-bid / best-ask on the CLOB (more accurate than
  last-trade price for thinly traded markets).
* Skips markets below MIN_MARKET_LIQUIDITY to avoid illiquid traps.

Temperature bin detection
-------------------------
Polymarket temperature questions look like:
  "Will the high temperature in New York on June 15 be above 85°F?"
  "Will the high temperature in Tokyo on June 15 be between 30°C and 35°C?"
  "Seoul high temperature June 15: 25–30°C?"

We try to handle all of these via a tiered parsing approach.
"""

from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from typing import Dict, List, Optional, Tuple

import requests
from cachetools import TTLCache, cached
from tenacity import retry, stop_after_attempt, wait_exponential

from config import cfg

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

@dataclass
class BinRange:
    """Represents a single temperature outcome bin."""
    low: Optional[float]    # None = no lower bound (e.g. "< 70°F")
    high: Optional[float]   # None = no upper bound (e.g. "> 90°F")
    unit: str               # "F" or "C"
    label: str              # original text label, e.g. "85–90°F"

    def contains(self, temp: float) -> bool:
        """Return True if temp (in this bin's unit) falls inside this range."""
        if self.low is not None and temp < self.low:
            return False
        if self.high is not None and temp >= self.high:
            return False
        return True

    def to_celsius(self) -> "BinRange":
        """Return a copy of this bin with values converted to Celsius."""
        if self.unit == "C":
            return self
        def _fc(f: Optional[float]) -> Optional[float]:
            return (f - 32) * 5 / 9 if f is not None else None
        return BinRange(low=_fc(self.low), high=_fc(self.high),
                        unit="C", label=self.label)


@dataclass
class WeatherMarket:
    """
    A single active Polymarket weather market, fully enriched.

    Fields map directly to what edge_calculator and trader need.
    """
    # ── Polymarket identifiers ─────────────────────────────────────────────
    condition_id:     str              # Polymarket condition ID
    market_slug:      str              # URL slug
    question:         str              # full question text
    clob_token_ids:   List[str]        # [yes_token, no_token] or multi-outcome
    tick_size:        float            # minimum_tick_size from CLOB
    neg_risk:         bool             # True → complement-risk market

    # ── Extracted semantics ────────────────────────────────────────────────
    city:             str              # matched city name
    target_date:      date             # the day the market resolves on
    bin_range:        BinRange         # temperature outcome this token represents
    outcome_index:    int              # index into clob_token_ids (0=Yes etc.)

    # ── Live market data ───────────────────────────────────────────────────
    mid_price:        float            # (best_bid + best_ask) / 2
    best_bid:         float
    best_ask:         float
    volume_usd:       float            # total market volume
    liquidity_usd:    float            # sum of top-N levels on both sides
    last_updated:     datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    @property
    def implied_prob(self) -> float:
        """Market-implied probability = mid_price (Polymarket prices ≡ probabilities)."""
        return self.mid_price

    @property
    def spread(self) -> float:
        return self.best_ask - self.best_bid

    def is_tradeable(self) -> bool:
        """Quick sanity check before passing to edge calculator."""
        return (
            self.volume_usd >= cfg.risk.min_market_liquidity
            and self.mid_price > 0.01
            and self.mid_price < 0.99
            and self.spread < 0.20  # skip markets wider than 20c
        )


# ---------------------------------------------------------------------------
# Gamma API client
# ---------------------------------------------------------------------------

class GammaClient:
    """Thin wrapper around the Polymarket Gamma REST API."""

    BASE = cfg.polymarket.gamma_host

    WEATHER_KEYWORDS = [
        "temperature", "high temp", "low temp", "weather",
        "forecast", "fahrenheit", "celsius", "°f", "°c",
        "rain", "snow", "precipitation", "heat",
    ]

    def __init__(self) -> None:
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "polymarket-weather-bot/1.0",
            "Accept": "application/json",
        })

    @retry(stop=stop_after_attempt(4),
           wait=wait_exponential(multiplier=1, min=2, max=30))
    def _get(self, path: str, params: dict | None = None) -> dict | list:
        url = f"{self.BASE}{path}"
        resp = self.session.get(url, params=params, timeout=15)
        resp.raise_for_status()
        return resp.json()

    # Slug pattern used by Polymarket for temperature markets.
    # Discovered by reading solship/Polymarket-Weather-Trading-Bot (nws.ts + polymarket.ts).
    # More reliable than tag/keyword search — directly targets the exact market URL.
    # Format: "highest-temperature-in-{city-slug}-on-{month}-{day}-{year}"
    SLUG_CITY_MAP: Dict[str, str] = {
        "New York":    "new-york",
        "Chicago":     "chicago",
        "Miami":       "miami",
        "Dallas":      "dallas",
        "Seattle":     "seattle",
        "Atlanta":     "atlanta",
        "Los Angeles": "los-angeles",
        "Houston":     "houston",
        "Phoenix":     "phoenix",
        "Denver":      "denver",
        "London":      "london",
        "Paris":       "paris",
        "Tokyo":       "tokyo",
        "Seoul":       "seoul",
        "Dubai":       "dubai",
        "Sydney":      "sydney",
        "Singapore":   "singapore",
        "Hong Kong":   "hong-kong",
        "Berlin":      "berlin",
        "Toronto":     "toronto",
        "Mumbai":      "mumbai",
        "Taipei":      "taipei",
        "Tel Aviv":    "tel-aviv",
    }

    _MONTHS = [
        "january","february","march","april","may","june",
        "july","august","september","october","november","december"
    ]

    def fetch_by_slug(self, city: str, target_date: "date") -> Optional[dict]:
        """
        Direct slug-based event lookup for one city + date.

        Why this beats tag search
        -------------------------
        Polymarket generates deterministic slugs for temperature markets:
            "highest-temperature-in-new-york-on-january-15-2025"
        Querying by slug returns the exact event with all its bin markets.
        Tag/keyword search can miss events, return wrong results, or hit
        rate limits on large scans.

        Credit: solship/Polymarket-Weather-Trading-Bot polymarket.ts
        """
        city_slug = self.SLUG_CITY_MAP.get(city)
        if not city_slug:
            return None
        slug = (
            f"highest-temperature-in-{city_slug}-on-"
            f"{self._MONTHS[target_date.month - 1]}-"
            f"{target_date.day}-{target_date.year}"
        )
        try:
            result = self._get("/events", params={"slug": slug})
            events = result if isinstance(result, list) else []
            if events:
                log.debug("Slug hit: %s", slug)
                return events[0]
        except Exception as exc:
            log.debug("Slug lookup failed for %s: %s", slug, exc)
        return None

    def fetch_weather_markets(
        self,
        limit: int = 500,
        active_only: bool = True,
    ) -> List[dict]:
        """
        Dual-strategy market discovery:

        Strategy 1 (PRIMARY) — Slug-based direct lookup.
          For each configured city × next 7 days, build the exact Polymarket
          event slug and query it directly. Deterministic, reliable, fast.
          Returns all bin markets (one per temperature range) inside each event.

        Strategy 2 (FALLBACK) — Gamma tag + keyword search.
          Catches any markets not covered by slug (non-standard formats,
          new city additions, etc.).
        """
        from datetime import date as _date, timedelta
        all_markets: List[dict] = []
        seen: set[str] = set()

        def _dedup_add(raw_list):
            for m in raw_list:
                cid = m.get("conditionId") or m.get("id", "")
                if cid and cid not in seen:
                    seen.add(cid)
                    all_markets.append(m)

        # ── Strategy 1: Slug lookup for all cities × 7-day window ────────────
        today = _date.today()
        slug_hits = 0
        for city in cfg.cities:
            for days_ahead in range(0, 7):
                event = self.fetch_by_slug(city, today + timedelta(days=days_ahead))
                if event:
                    markets = event.get("markets", [])
                    before = len(seen)
                    _dedup_add(markets)
                    slug_hits += len(seen) - before

        log.info("Slug discovery: %d new markets", slug_hits)

        # ── Strategy 2: Tag + keyword fallback ───────────────────────────────
        for tag in ("Weather", "Forecast"):
            try:
                result = self._get("/markets", params={
                    "tag": tag,
                    "active": "true" if active_only else "false",
                    "limit": limit,
                })
                raw = result if isinstance(result, list) else result.get("markets", [])
                _dedup_add(raw)
            except Exception as exc:
                log.warning("Gamma tag search failed for %r: %s", tag, exc)

        for kw in ("temperature", "high temp"):
            try:
                result = self._get("/markets", params={
                    "search": kw,
                    "active": "true" if active_only else "false",
                    "limit": limit,
                })
                raw = result if isinstance(result, list) else result.get("markets", [])
                _dedup_add(raw)
            except Exception as exc:
                log.warning("Gamma keyword search failed for %r: %s", kw, exc)

        log.info("Total unique weather-candidate markets: %d", len(all_markets))
        return all_markets

    def fetch_events(self, limit: int = 200) -> List[dict]:
        """Pull top-level events (groups of markets) for weather tags."""
        results: List[dict] = []
        for tag in ("Weather", "Forecast"):
            try:
                data = self._get("/events", params={"tag": tag, "limit": limit})
                events = data if isinstance(data, list) else data.get("events", [])
                results.extend(events)
            except Exception as exc:
                log.warning("Gamma events fetch failed for tag %r: %s", tag, exc)
        return results


# ---------------------------------------------------------------------------
# CLOB orderbook enrichment
# ---------------------------------------------------------------------------

class ClobEnricher:
    """Fetches live mid-prices and liquidity from the CLOB REST endpoint."""

    BASE = cfg.polymarket.clob_host

    def __init__(self) -> None:
        self.session = requests.Session()
        self.session.headers["User-Agent"] = "polymarket-weather-bot/1.0"

    @retry(stop=stop_after_attempt(3),
           wait=wait_exponential(multiplier=1, min=1, max=10))
    def get_orderbook(self, token_id: str) -> dict:
        """Return raw orderbook dict for one token."""
        resp = self.session.get(
            f"{self.BASE}/book",
            params={"token_id": token_id},
            timeout=10,
        )
        resp.raise_for_status()
        return resp.json()

    def get_mid_price(self, token_id: str) -> Tuple[float, float, float, float]:
        """
        Returns (mid_price, best_bid, best_ask, liquidity_usd).
        liquidity_usd = sum of top-5 bid + ask levels in dollars.
        """
        try:
            book = self.get_orderbook(token_id)
        except Exception as exc:
            log.debug("Orderbook fetch failed for token %s: %s", token_id, exc)
            return 0.0, 0.0, 0.0, 0.0

        bids: List[dict] = book.get("bids", [])
        asks: List[dict] = book.get("asks", [])

        best_bid  = float(bids[0]["price"]) if bids else 0.0
        best_ask  = float(asks[0]["price"]) if asks else 1.0

        mid = (best_bid + best_ask) / 2 if (bids and asks) else best_bid or best_ask

        # Liquidity = dollar value in top-5 levels on each side
        top = 5
        liq = sum(float(b["price"]) * float(b["size"]) for b in bids[:top])
        liq += sum(float(a["price"]) * float(a["size"]) for a in asks[:top])

        return mid, best_bid, best_ask, liq


# ---------------------------------------------------------------------------
# Market parser — extracts city, date, and bin range from question text
# ---------------------------------------------------------------------------

class MarketParser:
    """
    Heuristic parser for Polymarket temperature-bin questions.

    Handles patterns like:
      "Will the high temperature in New York on June 15 be above 85°F?"
      "Seoul high temperature June 15: 25–30°C?"
      "Will Tokyo reach 35°C or higher on June 20?"
    """

    # Matches things like "85°F", "30°C", "85 F", "30 C"
    _TEMP_RE = re.compile(
        r"""
        (?P<low>-?\d+(?:\.\d+)?)\s*°?\s*(?P<unit1>[FC])   # lower bound
        (?:                                                  # optional range
            \s*(?:–|-|to|and)\s*
            (?P<high>-?\d+(?:\.\d+)?)\s*°?\s*(?P<unit2>[FC])?
        )?
        """,
        re.IGNORECASE | re.VERBOSE,
    )

    # Matches standalone thresholds: "above 85°F", "below 30°C"
    _THRESHOLD_RE = re.compile(
        r"(above|over|higher than|below|under|lower than)\s+"
        r"(-?\d+(?:\.\d+)?)\s*°?\s*([FC])",
        re.IGNORECASE,
    )

    # Date patterns
    _DATE_PATTERNS = [
        # "June 15", "Jun 15", "June 15, 2025"
        r"(?P<month>Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|"
        r"May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|"
        r"Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)"
        r"\s+(?P<day>\d{1,2})(?:,?\s+(?P<year>\d{4}))?",
        # "2025-06-15"
        r"(?P<year2>\d{4})-(?P<month2>\d{2})-(?P<day2>\d{2})",
        # "15 June 2025"
        r"(?P<day3>\d{1,2})\s+(?P<month3>Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|"
        r"Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|"
        r"Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+(?P<year3>\d{4})",
    ]

    def extract_city(self, question: str, candidate_cities: List[str]) -> Optional[str]:
        """Find the first configured city name mentioned in the question."""
        q_lower = question.lower()
        # Longer names first to avoid "New" matching before "New York"
        for city in sorted(candidate_cities, key=len, reverse=True):
            if city.lower() in q_lower:
                return city
        return None

    def extract_date(self, question: str) -> Optional[date]:
        """Parse the target date from the question text."""
        current_year = datetime.now().year

        for pattern in self._DATE_PATTERNS:
            m = re.search(pattern, question, re.IGNORECASE)
            if not m:
                continue
            gd = m.groupdict()
            try:
                if gd.get("month"):
                    month_str = gd["month"][:3].title()
                    month = datetime.strptime(month_str, "%b").month
                    day   = int(gd["day"])
                    year  = int(gd.get("year") or current_year)
                    return date(year, month, day)
                elif gd.get("month2"):
                    return date(int(gd["year2"]), int(gd["month2"]), int(gd["day2"]))
                elif gd.get("month3"):
                    month_str = gd["month3"][:3].title()
                    month = datetime.strptime(month_str, "%b").month
                    day   = int(gd["day3"])
                    year  = int(gd["year3"])
                    return date(year, month, day)
            except (ValueError, TypeError):
                continue

        return None

    def extract_bin(self, question: str) -> Optional[BinRange]:
        """
        Extract the temperature bin this market resolves to.
        Returns None if we can't confidently parse it.
        """
        # Try threshold pattern first ("above 85°F", "below 30°C")
        t = self._THRESHOLD_RE.search(question)
        if t:
            direction = t.group(1).lower()
            val       = float(t.group(2))
            unit      = t.group(3).upper()
            if direction in ("above", "over", "higher than"):
                return BinRange(low=val, high=None, unit=unit,
                                label=f">{val}°{unit}")
            else:
                return BinRange(low=None, high=val, unit=unit,
                                label=f"<{val}°{unit}")

        # Try range pattern ("85–90°F", "30 to 35°C")
        for m in self._TEMP_RE.finditer(question):
            gd = m.groupdict()
            low  = float(gd["low"])
            high = float(gd["high"]) if gd.get("high") else None
            unit = (gd.get("unit2") or gd["unit1"]).upper()
            if high:
                label = f"{low}–{high}°{unit}"
                return BinRange(low=low, high=high, unit=unit, label=label)

        return None

    def is_temperature_market(self, question: str) -> bool:
        q = question.lower()
        return any(kw in q for kw in [
            "temperature", "high temp", "low temp",
            "°f", "°c", "fahrenheit", "celsius",
        ])


# ---------------------------------------------------------------------------
# Main scanner — public API
# ---------------------------------------------------------------------------

# TTL cache: re-scan Polymarket at most once per scan_interval window
_market_cache: TTLCache = TTLCache(
    maxsize=1,
    ttl=cfg.scheduler.scan_interval_seconds,
)


class MarketScanner:
    """
    Orchestrates market discovery, parsing, and CLOB enrichment.

    Usage
    -----
        scanner = MarketScanner()
        markets = scanner.get_active_weather_markets()
        for m in markets:
            print(m.city, m.bin_range.label, m.implied_prob)
    """

    def __init__(self) -> None:
        self.gamma  = GammaClient()
        self.clob   = ClobEnricher()
        self.parser = MarketParser()

    # ── Internal helpers ──────────────────────────────────────────────────

    def _parse_market(self, raw: dict) -> List[WeatherMarket]:
        """
        Convert one raw Gamma market dict into 0–N WeatherMarket objects.
        Returns a list because a single event may contain multiple outcome
        tokens (one per bin), each becoming its own WeatherMarket.
        """
        question = raw.get("question") or raw.get("title") or ""
        if not self.parser.is_temperature_market(question):
            return []

        city = self.parser.extract_city(question, cfg.cities)
        if city is None:
            return []

        target_date = self.parser.extract_date(question)
        if target_date is None:
            log.debug("Could not parse date from: %r", question)
            return []

        # Skip markets resolving in the past
        if target_date < date.today():
            return []

        # Token IDs — may be a list (binary Yes/No) or dict
        clob_ids_raw = raw.get("clobTokenIds") or raw.get("clob_token_ids") or []
        if isinstance(clob_ids_raw, str):
            import json as _json
            try:
                clob_ids_raw = _json.loads(clob_ids_raw)
            except Exception:
                clob_ids_raw = [clob_ids_raw]

        clob_token_ids: List[str] = [str(t) for t in clob_ids_raw]
        if not clob_token_ids:
            log.debug("No CLOB token IDs for market: %r", question)
            return []

        condition_id = raw.get("conditionId") or raw.get("condition_id", "")
        neg_risk     = bool(raw.get("negRisk") or raw.get("neg_risk", False))
        tick_size    = float(raw.get("minimumTickSize") or raw.get("minimum_tick_size") or 0.01)
        volume_usd   = float(raw.get("volume") or raw.get("volumeUsd") or 0.0)
        market_slug  = raw.get("slug") or raw.get("marketSlug") or condition_id

        # Bin extraction — for binary markets the question IS the bin
        bin_range = self.parser.extract_bin(question)
        if bin_range is None:
            log.debug("Could not parse bin from: %r", question)
            return []

        results: List[WeatherMarket] = []

        # For binary Yes/No markets, token 0 = Yes (the stated condition)
        # For multi-outcome, each token ID maps to a separate bin —
        # we only have the question-level bin here, so we emit one entry.
        for idx, token_id in enumerate(clob_token_ids[:1]):  # Yes token only
            mid, bid, ask, liq = self.clob.get_mid_price(token_id)

            wm = WeatherMarket(
                condition_id=condition_id,
                market_slug=market_slug,
                question=question,
                clob_token_ids=clob_token_ids,
                tick_size=tick_size,
                neg_risk=neg_risk,
                city=city,
                target_date=target_date,
                bin_range=bin_range,
                outcome_index=idx,
                mid_price=mid,
                best_bid=bid,
                best_ask=ask,
                volume_usd=volume_usd,
                liquidity_usd=liq,
            )
            results.append(wm)

        return results

    # ── Public API ────────────────────────────────────────────────────────

    def get_active_weather_markets(
        self,
        force_refresh: bool = False,
    ) -> List[WeatherMarket]:
        """
        Return all active, parseable, liquid weather markets.

        Results are cached for scan_interval_seconds to reduce API load.
        Pass force_refresh=True to bypass the cache.
        """
        cache_key = "markets"
        if not force_refresh and cache_key in _market_cache:
            cached_result = _market_cache[cache_key]
            log.debug("Returning %d markets from cache", len(cached_result))
            return cached_result

        log.info("Scanning Polymarket for active weather markets…")
        t0 = time.monotonic()

        raw_markets = self.gamma.fetch_weather_markets()
        log.info("Fetched %d raw market candidates", len(raw_markets))

        parsed: List[WeatherMarket] = []
        for raw in raw_markets:
            try:
                parsed.extend(self._parse_market(raw))
            except Exception as exc:
                log.warning("Failed to parse market %r: %s",
                            raw.get("conditionId", "?"), exc)

        # Apply liquidity filter
        tradeable = [m for m in parsed if m.volume_usd >= cfg.risk.min_market_liquidity]

        elapsed = time.monotonic() - t0
        log.info(
            "Scanner: %d parsed → %d liquid markets in %.1fs",
            len(parsed), len(tradeable), elapsed,
        )

        _market_cache[cache_key] = tradeable
        return tradeable

    def get_markets_by_city(self, city: str) -> List[WeatherMarket]:
        """Convenience: return only markets for one city."""
        return [m for m in self.get_active_weather_markets() if m.city == city]

    def get_markets_by_date(self, target: date) -> List[WeatherMarket]:
        """Convenience: return only markets resolving on a specific date."""
        return [m for m in self.get_active_weather_markets() if m.target_date == target]

    def summarize(self) -> str:
        """Return a one-line human-readable summary for logging/alerts."""
        markets = self.get_active_weather_markets()
        cities  = {m.city for m in markets}
        return (
            f"Active weather markets: {len(markets)} across "
            f"{len(cities)} cities: {', '.join(sorted(cities))}"
        )


# ---------------------------------------------------------------------------
# CLI quick-test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import json

    logging.basicConfig(level=logging.DEBUG)
    scanner = MarketScanner()
    markets = scanner.get_active_weather_markets()
    print(f"\nFound {len(markets)} markets:\n")
    for m in markets[:10]:
        print(
            f"  [{m.city}] {m.target_date} | {m.bin_range.label} | "
            f"mid={m.mid_price:.3f} | vol=${m.volume_usd:,.0f} | "
            f"tradeable={m.is_tradeable()}"
        )
    print("\n" + scanner.summarize())
