"""
edge_calculator.py  (v2 — mathematically corrected)
====================================================
Computes true edge, correct EV, fee-adjusted Kelly sizing,
and LMSR price impact for every potential trade.

Corrections vs v1
-----------------
BUG 1 — EV formula was wrong:
    v1:  ev_gross = edge × payout = (p-P)(1/P-1)     ← WRONG
    v2:  ev_gross = edge / price  = (p-P)/P           ← CORRECT

    Derivation:
        Bet $1 at price P.  Win (prob p): profit = 1/P - 1.  Lose: profit = -1.
        EV = p(1/P-1) + (1-p)(-1) = p/P - p - 1 + p = p/P - 1 = (p-P)/P = edge/P

    At p=0.65, P=0.45:  v1 gave 0.244, correct is 0.444.
    v1 was understating EV by ~45% → blocking profitable trades.

BUG 2 — Kelly ignored fees:
    v1:  f* = (b·p - q) / b   where b = payout           ← no fees
    v2:  W  = payout - fee    (net gain per $ if win)
         L  = 1 + fee         (net loss per $ if lose)
         f* = (p·W - q·L) / (W·L)                        ← fee-adjusted Kelly

    This is derived from maximising E[log(wealth)] with asymmetric payouts.

BUG 3 (new feature) — LMSR price impact model:
    Binary LMSR with parameter b:
        Current price: P = sigmoid(q_Y / b)  → q_Y = b·ln(P/(1-P))
        After buying δ YES shares:
            q_Y' = q_Y + δ
            P'   = sigmoid(q_Y' / b)
        Cost   = b·[ln(e^(q_Y'/b) + 1) - ln(e^(q_Y/b) + 1)]
        Impact = P' - P
    Linear approximation (fast check): ΔP ≈ δ·P(1-P)/b

NEW — Uncertainty-adjusted Kelly:
    The probability calculator returns (p, uncertainty) where uncertainty
    is the posterior std or KDE bandwidth ratio.
    We shrink Kelly by a confidence factor:
        kelly_adjusted = kelly_fee × confidence_factor
        confidence_factor = 1 / (1 + k_uncertainty × uncertainty)
    This reduces bet size when the ensemble is spread thin or
    sources disagree.
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass
from typing import Optional, Tuple

import numpy as np

from config import cfg
from market_scanner import WeatherMarket

log = logging.getLogger(__name__)

# ── Fee constants ─────────────────────────────────────────────────────────────
# Polymarket taker fee (worst case). Use 0.01 if you place limit orders.
TAKER_FEE_RATE: float = 0.02    # 2% on amount wagered
MAKER_FEE_RATE: float = 0.01    # 1% if you rest as maker

# We assume taker fill for conservatism.
ASSUMED_FEE: float = TAKER_FEE_RATE

# ── EV threshold ──────────────────────────────────────────────────────────────
# Minimum net EV (per dollar wagered) after fees + slippage.
# Set higher than v1 (0.02) because our EV formula is now correct.
MIN_EV_PER_DOLLAR: float = 0.04

# ── Uncertainty scaling ───────────────────────────────────────────────────────
# How much to penalise Kelly for high probability uncertainty.
# kelly_final = kelly × 1/(1 + K_UNCERTAINTY × uncertainty)
# At uncertainty=0: no penalty.  At uncertainty=0.1 (high): ×0.5 reduction.
K_UNCERTAINTY: float = 5.0

# ── LMSR config ───────────────────────────────────────────────────────────────
# If we can't read b from the market, fall back to this default.
DEFAULT_LMSR_B: float = 100.0

# Max acceptable price impact from our trade (fraction of edge).
# If our order would move the price by more than this, reduce size.
MAX_IMPACT_FRACTION: float = 0.5    # don't let our trade eat >50% of edge


# ─────────────────────────────────────────────────────────────────────────────
# LMSR price impact model
# ─────────────────────────────────────────────────────────────────────────────

def lmsr_price_impact(
    price:     float,      # current YES price (0–1)
    shares:    float,      # number of YES shares to buy (= usd / price)
    b:         float = DEFAULT_LMSR_B,
) -> Tuple[float, float]:
    """
    Compute LMSR price impact and average fill price for a given share count.

    Binary LMSR model (2 outcomes: YES, NO):
        Cost function: C(q_Y, q_N) = b·ln(e^(q_Y/b) + e^(q_N/b))
        Normalise q_N = 0: C(q_Y) = b·ln(e^(q_Y/b) + 1)
        Current price: P = dC/dq_Y = e^(q_Y/b) / (e^(q_Y/b) + 1) = sigmoid(q_Y/b)
        → q_Y = b·ln(P/(1-P))  [inverse sigmoid scaled by b]

    After buying δ YES shares:
        q_Y' = q_Y + δ
        P'   = sigmoid(q_Y'/b)
        Cost = C(q_Y') - C(q_Y) = b·[ln(e^(q_Y'/b)+1) - ln(e^(q_Y/b)+1)]
        Avg fill price = Cost / δ

    Parameters
    ----------
    price  : current mid-price of YES
    shares : number of YES shares to purchase (positive = buying)
    b      : LMSR liquidity parameter (higher b = less price impact)

    Returns
    -------
    (price_after_trade, average_fill_price)
    """
    price  = float(np.clip(price,  1e-6, 1-1e-6))
    shares = max(0.0, float(shares))

    if shares < 0.001:
        return price, price

    # Current quantity implied by price
    q_Y  = b * math.log(price / (1.0 - price))

    # New quantity after trade
    q_Y2 = q_Y + shares

    # New price (can't exceed 1)
    p_new = 1.0 / (1.0 + math.exp(-q_Y2 / b))
    p_new = float(np.clip(p_new, price, 0.999))  # always moves price up when buying

    # Cost of trade (exact LMSR)
    # Use log-sum-exp trick for numerical stability
    def _log1pexp(x: float) -> float:
        if x > 30:   return x           # log(e^x + 1) ≈ x for large x
        if x < -30:  return math.exp(x)  # log(e^x + 1) ≈ e^x for small x
        return math.log(1.0 + math.exp(x))

    cost = b * (_log1pexp(q_Y2 / b) - _log1pexp(q_Y / b))
    avg_fill = cost / shares if shares > 0 else price

    return p_new, float(np.clip(avg_fill, price, 0.999))


def lmsr_impact_linear(
    price:  float,
    shares: float,
    b:      float = DEFAULT_LMSR_B,
) -> float:
    """
    Fast linear approximation of LMSR price impact.
    ΔP ≈ shares × P × (1-P) / b

    Good enough for a quick pre-trade rejection check.
    """
    return shares * price * (1.0 - price) / b


# ─────────────────────────────────────────────────────────────────────────────
# Result type
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class EdgeResult:
    """
    All edge and sizing information for one potential trade.
    Every field has an explicit formula reference.
    """
    # ── Market identifiers ────────────────────────────────────────────────
    condition_id:  str
    city:          str
    target_date:   object   # date
    bin_label:     str
    side:          str      # "YES" or "NO"

    # ── Probabilities ─────────────────────────────────────────────────────
    model_prob:    float    # our ensemble/Bayesian probability
    prob_uncertainty: float # posterior std — how confident we are in model_prob
    market_price:  float    # Polymarket mid (= implied probability)

    # ── Edge ──────────────────────────────────────────────────────────────
    edge:          float    # model_prob - market_price  (signed)

    # ── EV (v2: correct formula ev = edge/price - fees) ───────────────────
    ev_gross:      float    # = edge / market_price  (before any costs)
    fee_cost:      float    # taker fee (fraction of amount wagered)
    slippage_cost: float    # half-spread estimate
    ev_net:        float    # = ev_gross - fee_cost - slippage_cost

    # ── LMSR price impact ─────────────────────────────────────────────────
    lmsr_b:           float  # LMSR liquidity param used
    shares_to_buy:    float  # position_usd / fill_price
    price_after_trade: float # P' after our order settles
    price_impact:     float  # P' - P_current  (how much we move the market)
    avg_fill_price:   float  # actual average cost per share (includes impact)
    ev_net_post_impact: float  # EV recalculated at avg_fill_price

    # ── Kelly sizing (v2: fee-adjusted) ───────────────────────────────────
    # Full Kelly (no fees):  f0 = (b·p - q) / b
    # Fee-adjusted Kelly:    W = payout - fee;  L = 1 + fee
    #                        f* = (p·W - q·L) / (W·L)
    # Uncertainty discount:  f_adj = f* × 1/(1 + K_UNCERTAINTY × uncertainty)
    # Fractional Kelly:      f_final = f_adj × KELLY_FRACTION
    kelly_no_fee:     float   # full Kelly ignoring fees (for reference)
    kelly_fee_adj:    float   # fee-corrected full Kelly
    kelly_uncertainty_adj: float  # further discounted for probability uncertainty
    kelly_final:      float   # × cfg.risk.kelly_fraction (e.g. ×0.25)
    position_usd:     float   # bankroll × kelly_final, capped
    bankroll_used_pct: float  # position_usd / bankroll × 100

    # ── Decision flags ────────────────────────────────────────────────────
    has_edge:     bool  # edge > cfg.risk.min_edge
    ev_positive:  bool  # ev_net_post_impact > MIN_EV_PER_DOLLAR
    is_tradeable: bool  # all checks pass
    note:         str = ""

    def one_liner(self) -> str:
        flag = "✅ TRADE" if self.is_tradeable else "❌ SKIP "
        return (
            f"{flag} | {self.city} {self.target_date} | "
            f"{self.bin_label} {self.side} | "
            f"model={self.model_prob:.3f}(±{self.prob_uncertainty:.3f}) "
            f"mkt={self.market_price:.3f} edge={self.edge:+.3f} | "
            f"ev_net={self.ev_net:+.4f} ev_post_impact={self.ev_net_post_impact:+.4f} | "
            f"kelly={self.kelly_final:.4f} size=${self.position_usd:.2f}"
        )


# ─────────────────────────────────────────────────────────────────────────────
# EdgeCalculator
# ─────────────────────────────────────────────────────────────────────────────

class EdgeCalculator:
    """
    Evaluates edge, EV, LMSR impact, and Kelly size for one market×probability.

    Usage
    -----
        calc = EdgeCalculator(bankroll=1000.0)
        result = calc.best_side(market, model_prob=0.65, uncertainty=0.05)
        print(result.one_liner())
    """

    def __init__(self, bankroll: float) -> None:
        self.bankroll = bankroll
        log.info("EdgeCalculator v2 initialised | bankroll=$%.2f", bankroll)

    # ── Public API ────────────────────────────────────────────────────────

    def evaluate(
        self,
        market:       WeatherMarket,
        model_prob:   float,
        uncertainty:  float = 0.0,
        side:         str   = "YES",
    ) -> EdgeResult:
        """
        Evaluate one side (YES or NO).

        Parameters
        ----------
        model_prob  : our probability that the Yes condition is True
        uncertainty : posterior std from ProbabilityCalculator (0 = certain)
        side        : "YES" or "NO"
        """
        if side == "NO":
            return self._compute(
                market=market,
                model_prob=1.0 - model_prob,
                market_price=1.0 - market.mid_price,
                uncertainty=uncertainty,
                side="NO",
            )
        return self._compute(
            market=market,
            model_prob=model_prob,
            market_price=market.mid_price,
            uncertainty=uncertainty,
            side="YES",
        )

    def best_side(
        self,
        market:      WeatherMarket,
        model_prob:  float,
        uncertainty: float = 0.0,
    ) -> EdgeResult:
        """
        Evaluate both YES and NO sides, return the one with higher post-impact EV.
        """
        yes = self.evaluate(market, model_prob, uncertainty, side="YES")
        no  = self.evaluate(market, model_prob, uncertainty, side="NO")

        if yes.is_tradeable and no.is_tradeable:
            return yes if yes.ev_net_post_impact >= no.ev_net_post_impact else no
        if yes.is_tradeable:
            return yes
        if no.is_tradeable:
            return no
        return yes if yes.ev_net_post_impact >= no.ev_net_post_impact else no

    # ── Core computation ──────────────────────────────────────────────────

    def _compute(
        self,
        market:       WeatherMarket,
        model_prob:   float,
        market_price: float,
        uncertainty:  float,
        side:         str,
    ) -> EdgeResult:
        """
        All calculations, step by step with formula references.
        """
        # Guard rails
        p  = float(np.clip(model_prob,   0.001, 0.999))
        P  = float(np.clip(market_price, 0.001, 0.999))
        q  = 1.0 - p
        u  = float(np.clip(uncertainty,  0.0,   1.0))

        # ── STEP 1: Edge ──────────────────────────────────────────────────
        # edge = model probability - implied market probability
        edge = p - P

        # ── STEP 2: Net odds (payout per $1 staked if win) ────────────────
        payout = (1.0 - P) / P     # = 1/P - 1

        # ── STEP 3: Gross EV per dollar wagered (v2 CORRECTED) ────────────
        # Derivation: Bet $1 at price P.
        #   Win (prob p): profit = 1/P - 1 = payout
        #   Lose (prob q): profit = -1
        #   EV = p(1/P - 1) + q(-1) = p/P - p - 1 + p = p/P - 1 = (p-P)/P
        #
        # v1 WRONG formula:  ev_gross = edge × payout = (p-P)(1/P-1)
        # v2 CORRECT:        ev_gross = edge / price  = (p-P)/P
        ev_gross = edge / P

        # ── STEP 4: Fee cost and slippage ────────────────────────────────
        # Taker fee applies to the dollar amount wagered (not the payout).
        fee_cost = ASSUMED_FEE
        # Conservative: half-spread slippage on entry
        slippage_cost = market.spread / 2.0

        # ── STEP 5: Net EV (before LMSR impact) ──────────────────────────
        ev_net = ev_gross - fee_cost - slippage_cost

        # ── STEP 6: Kelly criterion, fee-adjusted (v2 CORRECTED) ──────────
        # No-fee Kelly for reference:  f0 = (b·p - q) / b = p - q/b
        kelly_no_fee = p - q / payout

        # Fee-adjusted Kelly:
        #   When win: net gain per dollar = payout - fee
        #   When lose: net loss per dollar = 1 + fee
        #   f* = (p·W - q·L) / (W·L)
        #   Derived from: max E[log(W)] with W = gain, L = loss per unit staked
        W = payout - ASSUMED_FEE
        L = 1.0 + ASSUMED_FEE
        if W <= 0:
            kelly_fee_adj = -1.0   # trade is unprofitable even if we win
        else:
            kelly_fee_adj = (p * W - q * L) / (W * L)

        # ── STEP 7: Uncertainty discount ──────────────────────────────────
        # We have uncertainty u in our probability estimate.
        # Scale Kelly down proportionally: more uncertainty → smaller bet.
        # confidence_factor = 1 / (1 + K_UNCERTAINTY × u)
        # At u=0: factor=1.0 (no reduction).  At u=0.1: factor≈0.67.
        confidence_factor = 1.0 / (1.0 + K_UNCERTAINTY * u)
        kelly_uncertainty_adj = kelly_fee_adj * confidence_factor

        # ── STEP 8: Fractional Kelly ──────────────────────────────────────
        # Quarter-Kelly: reduces variance by (0.25)² = 1/16 while keeping
        # 0.25 of the EV. Standard recommendation for prediction markets.
        kelly_final = kelly_uncertainty_adj * cfg.risk.kelly_fraction

        # ── STEP 9: Dollar size, capped ───────────────────────────────────
        raw_usd           = self.bankroll * kelly_final
        cap_pct           = self.bankroll * cfg.risk.max_bankroll_pct
        cap_abs           = cfg.risk.max_order_usd
        position_usd      = max(0.0, min(raw_usd, cap_pct, cap_abs))
        bankroll_used_pct = (position_usd / self.bankroll * 100.0) if self.bankroll else 0.0

        # ── STEP 10: LMSR price impact ────────────────────────────────────
        # How much does our order move the market price?
        # If impact eats into our edge, we need to reduce size or skip.
        lmsr_b = DEFAULT_LMSR_B
        shares = position_usd / P if P > 0 else 0.0

        p_after, avg_fill = lmsr_price_impact(P, shares, lmsr_b)
        impact            = p_after - P

        # EV recalculated at avg_fill price (more realistic)
        # If we buy at avg_fill instead of P, our effective edge shrinks:
        edge_post_impact = p - avg_fill
        if avg_fill < 0.999:
            ev_net_post_impact = edge_post_impact / avg_fill - fee_cost - slippage_cost
        else:
            ev_net_post_impact = -1.0   # filled so high we can't win

        # If price impact is too large relative to our edge, reduce size
        # until the impact is ≤ MAX_IMPACT_FRACTION × edge.
        if impact > MAX_IMPACT_FRACTION * edge and edge > 0 and lmsr_b > 0:
            # Solve: ΔP_linear = δ·P(1-P)/b ≤ MAX_IMPACT_FRACTION·edge
            max_shares = MAX_IMPACT_FRACTION * edge * lmsr_b / max(P * (1 - P), 0.001)
            max_usd    = max_shares * P
            if max_usd < position_usd:
                position_usd      = max(0.0, max_usd)
                bankroll_used_pct = (position_usd / self.bankroll * 100.0) if self.bankroll else 0.0
                shares            = position_usd / P if P > 0 else 0.0
                p_after, avg_fill = lmsr_price_impact(P, shares, lmsr_b)
                impact            = p_after - P
                edge_post_impact  = p - avg_fill
                ev_net_post_impact = (edge_post_impact / avg_fill - fee_cost - slippage_cost
                                      if avg_fill < 0.999 else -1.0)

        # ── STEP 11: Decision flags ───────────────────────────────────────
        has_edge     = edge           > cfg.risk.min_edge
        ev_positive  = ev_net_post_impact > MIN_EV_PER_DOLLAR
        is_tradeable = (
            has_edge
            and ev_positive
            and kelly_fee_adj > 0          # Kelly says bet
            and position_usd  >= 1.0       # minimum order size
            and market.is_tradeable()      # liquidity / spread check
        )

        note = self._build_note(
            edge, ev_gross, ev_net, ev_net_post_impact,
            kelly_no_fee, kelly_fee_adj, kelly_final,
            position_usd, impact, u, confidence_factor,
            is_tradeable,
        )

        result = EdgeResult(
            condition_id=market.condition_id,
            city=market.city,
            target_date=market.target_date,
            bin_label=market.bin_range.label,
            side=side,
            model_prob=p,
            prob_uncertainty=u,
            market_price=P,
            edge=edge,
            ev_gross=ev_gross,
            fee_cost=fee_cost,
            slippage_cost=slippage_cost,
            ev_net=ev_net,
            lmsr_b=lmsr_b,
            shares_to_buy=shares,
            price_after_trade=p_after,
            price_impact=impact,
            avg_fill_price=avg_fill,
            ev_net_post_impact=ev_net_post_impact,
            kelly_no_fee=kelly_no_fee,
            kelly_fee_adj=kelly_fee_adj,
            kelly_uncertainty_adj=kelly_uncertainty_adj,
            kelly_final=kelly_final,
            position_usd=position_usd,
            bankroll_used_pct=bankroll_used_pct,
            has_edge=has_edge,
            ev_positive=ev_positive,
            is_tradeable=is_tradeable,
            note=note,
        )

        log.info(result.one_liner())
        return result

    # ── Diagnostics ───────────────────────────────────────────────────────

    @staticmethod
    def _build_note(
        edge: float, ev_gross: float, ev_net: float, ev_post: float,
        kelly0: float, kelly_fee: float, kelly_final: float,
        pos_usd: float, impact: float, uncertainty: float,
        conf_factor: float, is_tradeable: bool,
    ) -> str:
        rejects = []
        if edge <= 0:
            rejects.append(f"edge={edge:+.4f}")
        elif edge <= cfg.risk.min_edge:
            rejects.append(f"edge={edge:.4f}<min({cfg.risk.min_edge})")
        if ev_post <= MIN_EV_PER_DOLLAR:
            rejects.append(f"ev_post={ev_post:.4f}<min({MIN_EV_PER_DOLLAR})")
        if kelly_fee <= 0:
            rejects.append(f"kelly_fee={kelly_fee:.4f}≤0")

        detail = (
            f"ev_gross={ev_gross:+.4f} ev_net={ev_net:+.4f} ev_post={ev_post:+.4f} | "
            f"kelly_raw={kelly0:.4f} kelly_fee={kelly_fee:.4f} "
            f"conf={conf_factor:.3f} kelly_final={kelly_final:.4f} | "
            f"impact={impact:+.4f} size=${pos_usd:.2f} u={uncertainty:.3f}"
        )
        prefix = "REJECT: " + " | ".join(rejects) if rejects else "OK:"
        return f"{prefix} {detail}"

    # ── Bankroll / daily loss ────────────────────────────────────────────

    def update_bankroll(self, new_bankroll: float) -> None:
        log.info("Bankroll: $%.2f → $%.2f", self.bankroll, new_bankroll)
        self.bankroll = new_bankroll

    def daily_loss_remaining(self, day_start: float) -> float:
        limit = day_start * cfg.risk.daily_loss_limit_pct
        lost  = max(0.0, day_start - self.bankroll)
        return max(0.0, limit - lost)

    def is_daily_limit_hit(self, day_start: float) -> bool:
        return self.daily_loss_remaining(day_start) <= 0.0


# ─────────────────────────────────────────────────────────────────────────────
# Convenience wrapper
# ─────────────────────────────────────────────────────────────────────────────

def evaluate_market(
    market:      WeatherMarket,
    model_prob:  float,
    bankroll:    float,
    uncertainty: float = 0.0,
) -> EdgeResult:
    """Stateless one-shot evaluation (used by main.py and tests)."""
    calc = EdgeCalculator(bankroll=bankroll)
    return calc.best_side(market, model_prob, uncertainty)


# ─────────────────────────────────────────────────────────────────────────────
# Self-test — prints a full breakdown with all corrections visible
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import logging
    from datetime import date
    from market_scanner import BinRange, WeatherMarket
    logging.basicConfig(level=logging.DEBUG)

    market = WeatherMarket(
        condition_id="0xTEST",
        market_slug="test",
        question="Will the high in New York be above 85°F on June 15?",
        clob_token_ids=["tok_yes", "tok_no"],
        tick_size=0.01,
        neg_risk=False,
        city="New York",
        target_date=date(2025, 6, 15),
        bin_range=BinRange(low=85, high=None, unit="F", label=">85°F"),
        outcome_index=0,
        mid_price=0.45,
        best_bid=0.44,
        best_ask=0.46,
        volume_usd=8500.0,
        liquidity_usd=2200.0,
    )

    calc = EdgeCalculator(bankroll=1000.0)
    result = calc.best_side(market, model_prob=0.65, uncertainty=0.08)

    print("\n" + "="*70)
    print("EDGE RESULT v2 (corrected math)")
    print("="*70)
    print(result.one_liner())
    print()
    print(f"  Edge:               {result.edge:+.4f}  ({result.edge*100:.1f}%)")
    print()
    print(f"  EV (CORRECTED):     ev_gross = edge/P = {result.ev_gross:+.4f}")
    print(f"    v1 WRONG would be: ev_gross = edge×payout = "
          f"{result.edge * ((1/result.market_price)-1):+.4f}")
    print(f"  After fees:         ev_net = {result.ev_net:+.4f}")
    print(f"  After LMSR impact:  ev_post = {result.ev_net_post_impact:+.4f}")
    print()
    print(f"  Kelly (no fees):    {result.kelly_no_fee:.4f}  ({result.kelly_no_fee*100:.2f}%)")
    print(f"  Kelly (fee-adj):    {result.kelly_fee_adj:.4f}  ({result.kelly_fee_adj*100:.2f}%)")
    print(f"  Conf factor (u={result.prob_uncertainty:.2f}): {1/(1+K_UNCERTAINTY*result.prob_uncertainty):.4f}")
    print(f"  Kelly (final ×{cfg.risk.kelly_fraction}): {result.kelly_final:.4f}  ({result.kelly_final*100:.2f}%)")
    print()
    print(f"  Position:           ${result.position_usd:.2f}  ({result.bankroll_used_pct:.2f}% of bankroll)")
    print()
    print(f"  LMSR impact:        {result.price_impact:+.4f}  "
          f"({result.market_price:.3f} → {result.price_after_trade:.3f})")
    print(f"  Avg fill price:     {result.avg_fill_price:.4f}")
    print()
    print(f"  Tradeable:          {result.is_tradeable}")
    print("="*70)
