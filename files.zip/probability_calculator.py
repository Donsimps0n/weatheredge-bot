"""
probability_calculator.py  (v2 — mathematically corrected)
===========================================================
Converts GFS ensemble samples into calibrated bin probabilities.

Corrections vs v1
-----------------
1. KDE fix: use kde.integrate_box_1d() — the correct scipy method.
   (v1 used stats.integrate.quad() which does not exist → always crashed
    and silently fell through to empirical; KDE was NEVER running in v1.)

2. Bayesian Beta-Binomial smoothing replaces raw k/n fraction.
   With only n=31 ensemble members, SE = sqrt(p(1-p)/31) ≈ 0.09.
   Raw fractions overstate confidence in tail bins.
   Posterior: Beta(α₀+k, β₀+n-k), posterior mean = (α₀+k)/(α₀+β₀+n).

3. Probability uncertainty (posterior std) is returned alongside the point
   estimate so the edge calculator can apply uncertainty-scaled sizing.

4. Consensus weighting is skill-score based (1/MSE_i weights), not fixed 0.8/0.2.

Mathematical Reference
----------------------
Let T = daily maximum temperature for a given city/date.
We observe n=31 GFS ensemble members: {t₁, t₂, …, t₃₁}.
The market resolves Yes iff T ∈ [lo, hi).

Method 1 — Empirical:    P̂ = k/n,  SE = sqrt(p̂(1-p̂)/n)

Method 2 — Bayesian Beta-Binomial:
    Prior: p ~ Beta(α₀, β₀)  [α₀=β₀=2, weak prior centred at 0.5]
    Posterior: p | k ~ Beta(α₀+k, β₀+n-k)
    Posterior mean: μ = (α₀+k) / (α₀+β₀+n)
    Posterior std:  σ = sqrt(μ(1-μ) / (α₀+β₀+n+1))

Method 3 — KDE (Gaussian kernel, Scott bandwidth):
    P(T ∈ [lo,hi)) = kde.integrate_box_1d(lo, hi)   ← CORRECT scipy method
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np
from scipy import stats
from scipy.stats import beta as beta_dist, norm as norm_dist

from market_scanner import BinRange, WeatherMarket
from forecast_fetcher import ForecastResult

log = logging.getLogger(__name__)

# Bayesian prior — Beta(α₀, β₀).  α₀=β₀=2: weakly centred at 0.5.
BETA_PRIOR_ALPHA: float = 2.0
BETA_PRIOR_BETA:  float = 2.0


# ─────────────────────────────────────────────────────────────────────────────
# Low-level estimators
# ─────────────────────────────────────────────────────────────────────────────

def _bin_hits(samples_c: List[float], bin_range: BinRange) -> Tuple[int, int]:
    """Return (k hits, n total) for the bin in Celsius."""
    bin_c = bin_range.to_celsius()
    k = sum(1 for t in samples_c if bin_c.contains(t))
    return k, len(samples_c)


def prob_empirical(samples_c: List[float], bin_range: BinRange) -> Tuple[float, float]:
    """
    Raw empirical probability P̂ = k/n.
    Returns (probability, standard_error).
    SE = sqrt(p̂(1-p̂)/n)  — binomial standard error.
    """
    k, n = _bin_hits(samples_c, bin_range)
    if n == 0:
        return 0.5, 0.5
    p_hat = k / n
    se    = float(np.sqrt(p_hat * (1 - p_hat) / n)) if n > 1 else 0.5
    return float(p_hat), se


def prob_bayesian(
    samples_c: List[float],
    bin_range: BinRange,
    alpha0: float = BETA_PRIOR_ALPHA,
    beta0:  float = BETA_PRIOR_BETA,
) -> Tuple[float, float]:
    """
    Beta-Binomial posterior probability estimate.

    Prior:     p ~ Beta(α₀, β₀)
    Posterior: p | data ~ Beta(α₀+k, β₀+n-k)
    Estimate:  posterior mean = (α₀+k) / (α₀+β₀+n)

    Returns (posterior_mean, posterior_std).
    posterior_std is our uncertainty — larger → bet smaller.

    Advantages over raw k/n:
      • Never returns exactly 0.0 or 1.0.
      • Shrinks extreme values toward 0.5 when sample is small.
      • Posterior std gives calibrated uncertainty for position scaling.
    """
    k, n = _bin_hits(samples_c, bin_range)
    a = alpha0 + k
    b = beta0  + (n - k)
    d = beta_dist(a, b)
    return float(d.mean()), float(d.std())


def prob_kde(
    samples_c: List[float],
    bin_range: BinRange,
) -> Tuple[float, float]:
    """
    Gaussian KDE probability estimate with exact integration.

    BUG FIX vs v1: use kde.integrate_box_1d(lo, hi).
    v1 used stats.integrate.quad() which does NOT exist in scipy → always
    raised AttributeError → silently fell through to empirical → KDE was
    never actually running.

    Returns (probability, bandwidth_ratio) where bandwidth_ratio is a
    proxy for uncertainty: bw / bin_width. Large values mean the KDE is
    smearing a lot of probability across boundaries.
    """
    if len(samples_c) < 5:
        return prob_bayesian(samples_c, bin_range)

    arr = np.array(samples_c, dtype=float)
    if arr.std() < 0.01:          # degenerate: all members identical
        return prob_bayesian(samples_c, bin_range)

    try:
        kde = stats.gaussian_kde(arr)    # Scott's bandwidth rule
    except Exception as exc:
        log.debug("KDE fit failed (%s), using Bayesian", exc)
        return prob_bayesian(samples_c, bin_range)

    bin_c   = bin_range.to_celsius()
    buf     = 3.0 * float(arr.std())     # buffer for open-ended bins
    lo      = float(bin_c.low)  if bin_c.low  is not None else float(arr.min()) - buf
    hi      = float(bin_c.high) if bin_c.high is not None else float(arr.max()) + buf

    try:
        # ── CORRECT integration ────────────────────────────────────────────
        # integrate_box_1d is scipy's built-in exact box integrator for KDEs.
        prob = float(kde.integrate_box_1d(lo, hi))
        prob = float(np.clip(prob, 0.0, 1.0))
    except Exception as exc:
        log.debug("KDE integration failed (%s), using Bayesian", exc)
        return prob_bayesian(samples_c, bin_range)

    # Uncertainty proxy: bandwidth / bin_width
    bw        = kde.factor * float(arr.std())
    bin_width = (hi - lo) if (bin_c.low is not None and bin_c.high is not None) else bw * 2
    bw_ratio  = bw / max(bin_width, 0.1)

    return prob, float(bw_ratio)


def prob_for_bin(
    samples_c: List[float],
    bin_range: BinRange,
    use_kde:   bool = True,
) -> Tuple[float, float]:
    """
    Best-estimate (probability, uncertainty) for one bin.

    Routing:
      - Interior bins (bounded both sides), n≥10: KDE → most accurate smoothing.
      - Tail bins (one bound open) or n<10: Bayesian → KDE tails are unreliable.
    """
    if not samples_c:
        return 0.5, 1.0

    bin_c   = bin_range.to_celsius()
    is_tail = (bin_c.low is None) or (bin_c.high is None)

    if use_kde and not is_tail and len(samples_c) >= 10:
        return prob_kde(samples_c, bin_range)
    return prob_bayesian(samples_c, bin_range)


# ─────────────────────────────────────────────────────────────────────────────
# Result containers
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class BinProbability:
    bin_range:   BinRange
    probability: float    # point estimate (posterior mean or KDE integral)
    uncertainty: float    # posterior std or KDE bw_ratio
    n_members:   int      # ensemble members in this bin
    n_total:     int

    @property
    def pct(self) -> float:
        return self.probability * 100

    @property
    def ci_95_half_width(self) -> float:
        """Approx 95% CI half-width on the probability estimate."""
        return 1.96 * self.uncertainty


@dataclass
class MarketDistribution:
    city:        str
    target_date: object     # date
    bin_probs:   List[BinProbability]
    source:      str
    n_members:   int
    normalised:  bool = False

    @property
    def total_prob(self) -> float:
        return sum(bp.probability for bp in self.bin_probs)

    @property
    def mean_uncertainty(self) -> float:
        return float(np.mean([bp.uncertainty for bp in self.bin_probs])) if self.bin_probs else 1.0

    def normalise(self) -> "MarketDistribution":
        total = self.total_prob
        if total < 0.001 or abs(total - 1.0) < 0.0005:
            self.normalised = True
            return self
        for bp in self.bin_probs:
            bp.probability /= total
        self.normalised = True
        return self

    def get_prob(self, bin_label: str) -> Optional[float]:
        for bp in self.bin_probs:
            if bp.bin_range.label == bin_label:
                return bp.probability
        return None

    def summary(self) -> str:
        lines = [
            f"Distribution: {self.city} {self.target_date} "
            f"(n={self.n_members}, mean_uncertainty={self.mean_uncertainty:.3f})"
        ]
        for bp in sorted(self.bin_probs, key=lambda x: x.bin_range.low or -999.0):
            bar = "█" * int(bp.pct / 2)
            ci  = f"±{bp.ci_95_half_width*100:.1f}%"
            lines.append(
                f"  {bp.bin_range.label:>15s}  {bp.pct:5.1f}% {ci:>8s}  "
                f"(n={bp.n_members:2d})  {bar}"
            )
        lines.append(f"  Total: {self.total_prob:.4f}")
        return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Main calculator
# ─────────────────────────────────────────────────────────────────────────────

class ProbabilityCalculator:
    """
    Converts ForecastResult into calibrated market probabilities.

    Usage
    -----
        calc = ProbabilityCalculator()
        p, u = calc.market_probability(market, forecast)
        # p  = probability that Yes resolves (0–1)
        # u  = uncertainty (0–1), fed into Kelly sizing as a discount factor
    """

    def __init__(self, use_kde: bool = True) -> None:
        self.use_kde = use_kde
        # Model weights: 1/MSE (updated by backtester). Equal until calibrated.
        self._model_weights: Dict[str, float] = {
            "open_meteo":  1.0,
            "tomorrow_io": 1.0,
            "openweather": 1.0,
        }

    def update_model_weights(self, mse_scores: Dict[str, float]) -> None:
        """
        Update weights from backtester calibration.
        mse_scores = {source_name: mean_squared_error_in_celsius_squared}
        Weights = (1/MSE_i) normalised to sum=1.
        """
        if not mse_scores:
            return
        inv = {k: 1.0 / max(v, 0.01) for k, v in mse_scores.items()}
        total = sum(inv.values())
        self._model_weights = {k: v / total for k, v in inv.items()}
        log.info("Model weights updated: %s", self._model_weights)

    def market_probability(
        self,
        market:   WeatherMarket,
        forecast: ForecastResult,
    ) -> Tuple[float, float]:
        """
        Return (probability, uncertainty) for a market's Yes condition.

        The uncertainty is passed to the edge calculator to discount Kelly
        sizing when the ensemble is spread thin.
        """
        samples_c = forecast.daily_max_samples
        if not samples_c:
            log.warning("Empty forecast samples for %s", market.city)
            return 0.5, 1.0

        p, u = prob_for_bin(samples_c, market.bin_range, use_kde=self.use_kde)
        log.debug(
            "P(%s | %s %s) = %.4f ± %.4f  (n=%d)",
            market.bin_range.label, market.city, market.target_date,
            p, u, len(samples_c),
        )
        return p, u

    def full_distribution(
        self,
        bins:      List[BinRange],
        forecast:  ForecastResult,
        normalise: bool = True,
    ) -> MarketDistribution:
        """Compute probabilities for all bins across a full ladder."""
        samples_c = forecast.daily_max_samples
        n_total   = len(samples_c)

        bin_probs: List[BinProbability] = []
        for b in bins:
            bin_c = b.to_celsius()
            n_in  = sum(1 for t in samples_c if bin_c.contains(t))
            p, u  = prob_for_bin(samples_c, b, use_kde=self.use_kde)
            bin_probs.append(BinProbability(
                bin_range=b, probability=p, uncertainty=u,
                n_members=n_in, n_total=n_total,
            ))

        dist = MarketDistribution(
            city=forecast.city, target_date=forecast.target_date,
            bin_probs=bin_probs, source=forecast.source, n_members=n_total,
        )
        if normalise:
            dist.normalise()
        log.info("\n%s", dist.summary())
        return dist

    def consensus_probability(
        self,
        market:   WeatherMarket,
        forecast: ForecastResult,
    ) -> Tuple[float, float, str]:
        """
        Skill-weighted consensus of ensemble + secondary sources.

        Weighting: 1/MSE_i  (sources with lower historical error get more weight).
        Converts secondary source point estimates to probabilities via
        N(mean_c, σ²) where σ = ensemble spread (best available proxy).

        Returns (blended_probability, blended_uncertainty, explanation).
        """
        p_ens, u_ens = self.market_probability(market, forecast)
        w_ens = self._model_weights.get("open_meteo", 1.0)

        if not forecast.consensus_means_c:
            return p_ens, u_ens, "ensemble only"

        sigma = max(forecast.std_max_c, 1.5)   # floor at 1.5°C
        bin_c = market.bin_range.to_celsius()
        lo    = float(bin_c.low)  if bin_c.low  is not None else -99.0
        hi    = float(bin_c.high) if bin_c.high is not None else 999.0

        probs_and_weights: List[Tuple[float, float]] = [(p_ens, w_ens)]

        for i, mean_c in enumerate(forecast.consensus_means_c):
            src  = forecast.consensus_sources[i] if i < len(forecast.consensus_sources) else f"src{i}"
            p_hi = norm_dist.cdf(hi, loc=mean_c, scale=sigma)
            p_lo = norm_dist.cdf(lo, loc=mean_c, scale=sigma)
            p_src = float(np.clip(p_hi - p_lo, 0.001, 0.999))
            w_src = self._model_weights.get(src, 1.0)
            probs_and_weights.append((p_src, w_src))

        total_w  = sum(w for _, w in probs_and_weights)
        blended  = sum(p * w for p, w in probs_and_weights) / total_w
        blended_u = float(np.std([p for p, _ in probs_and_weights]))

        note = (
            f"blend n={len(probs_and_weights)} "
            f"w={[round(w/total_w,2) for _,w in probs_and_weights]} "
            f"→ {blended:.4f} ± {blended_u:.4f}"
        )
        log.info("Consensus: %s %s | %s", market.city, market.target_date, note)
        return float(np.clip(blended, 0.01, 0.99)), blended_u, note

    # ── Bin builders ──────────────────────────────────────────────────────

    @staticmethod
    def make_fahrenheit_bins(thresholds: List[float]) -> List[BinRange]:
        bins = [BinRange(None, thresholds[0], "F", f"<{thresholds[0]}°F")]
        for lo, hi in zip(thresholds[:-1], thresholds[1:]):
            bins.append(BinRange(lo, hi, "F", f"{lo}–{hi}°F"))
        bins.append(BinRange(thresholds[-1], None, "F", f">{thresholds[-1]}°F"))
        return bins

    @staticmethod
    def make_celsius_bins(thresholds: List[float]) -> List[BinRange]:
        bins = [BinRange(None, thresholds[0], "C", f"<{thresholds[0]}°C")]
        for lo, hi in zip(thresholds[:-1], thresholds[1:]):
            bins.append(BinRange(lo, hi, "C", f"{lo}–{hi}°C"))
        bins.append(BinRange(thresholds[-1], None, "C", f">{thresholds[-1]}°C"))
        return bins


# ─────────────────────────────────────────────────────────────────────────────
# Self-test
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys
    from datetime import date
    logging.basicConfig(level=logging.DEBUG)

    np.random.seed(42)
    # Synthetic ensemble: N(28°C, 2.5°C std), 31 members
    samples_c = list(np.random.normal(28.0, 2.5, 31))

    bins_c = [
        BinRange(None, 24, "C", "<24°C"),
        BinRange(24,   27, "C", "24–27°C"),
        BinRange(27,   30, "C", "27–30°C"),
        BinRange(30,   33, "C", "30–33°C"),
        BinRange(33, None, "C", ">33°C"),
    ]

    print("\n── Estimator comparison (true dist = N(28, 2.5²)) ──")
    print(f"{'Bin':>12}  {'empirical':>10}  {'bayesian':>10}  {'kde':>10}  {'truth':>10}")

    from scipy.stats import norm as _norm
    for b in bins_c:
        lo = b.low  if b.low  is not None else -99.0
        hi = b.high if b.high is not None else  99.0
        truth = _norm.cdf(hi, 28, 2.5) - _norm.cdf(lo, 28, 2.5)
        p_emp, _  = prob_empirical(samples_c, b)
        p_bay, _  = prob_bayesian(samples_c, b)
        p_kde, _  = prob_kde(samples_c, b)
        print(f"  {b.label:>10s}  {p_emp:>10.4f}  {p_bay:>10.4f}  {p_kde:>10.4f}  {truth:>10.4f}")

    # Verify KDE is actually running (not crashing)
    p_kde_test, _ = prob_kde(samples_c, bins_c[2])
    assert p_kde_test > 0, "KDE returned 0 — integration is broken"
    print(f"\n✅ KDE integration working correctly: p={p_kde_test:.4f}")
